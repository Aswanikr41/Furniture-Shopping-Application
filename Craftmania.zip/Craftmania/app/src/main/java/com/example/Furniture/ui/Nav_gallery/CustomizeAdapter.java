package com.example.Furniture.ui.Nav_gallery;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.example.Furniture.Config;
import com.example.Furniture.R;
import com.example.Furniture.Session;
import com.example.Furniture.payment1;
import com.squareup.picasso.Picasso;

import org.json.JSONException;
import org.json.JSONObject;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

public class CustomizeAdapter extends RecyclerView.Adapter<CustomizeAdapter.MyViewHolder>{
    Context mCtx;
    private List<CustomizeModel> dataModelArrayList;
    private LayoutInflater inflater;


    public CustomizeAdapter(Context mCtx, List<CustomizeModel> dataModelArrayList) {
        this.mCtx = mCtx;
        this.dataModelArrayList = dataModelArrayList;
        inflater = LayoutInflater.from(mCtx);

    }



    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = inflater.inflate(R.layout.list_custom, parent, false);
        MyViewHolder holder = new MyViewHolder(view);
        return holder;
    }



    @Override
    public void onBindViewHolder(@NonNull MyViewHolder holder, @SuppressLint("RecyclerView") final int position) {
        final CustomizeModel model = dataModelArrayList.get(position);
        holder.cname.setText(model.getPname());
        holder.cprice.setText("Price:" + model.getAmount());
        holder.cq.setText("Quantity:" + model.getQn());
        Picasso.get().load(Config.imageURL + dataModelArrayList.get(position).getImage()).into(holder.img);
      holder.button.setOnClickListener(new View.OnClickListener() {
          @Override
          public void onClick(View view) {
              fetching(model.getId(),model.getPname(),model.getQn(),model.getAmount(),model.getImage());


          }
      });






    }

    private void fetching(String id,String pname, String qn, String amount, String image) {
        String userid,bdate,btime,username,phone,location;
        String url=Config.baseURL+"Buy.php";
        bdate = new SimpleDateFormat("dd/MM/yyyy", Locale.getDefault()).format(new Date());
        btime = new SimpleDateFormat("HH:mm:ss", Locale.getDefault()).format(new Date());

        HashMap<String, String> user = new Session(mCtx).getUserDetails();
        userid=user.get("id");
        username=user.get("username");
        phone=user.get("mobilenumber");
        location=user.get("location");
        final String[] status = new String[1];

        StringRequest s = new StringRequest(Request.Method.POST, url,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        try {
                            Toast.makeText(mCtx, response, Toast.LENGTH_SHORT).show();

                            JSONObject c = new JSONObject(response);
                            status[0] = c.getString("status");


                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                        if ("1".equals(status[0])) {
                            Toast.makeText(mCtx, "Order Booked", Toast.LENGTH_SHORT).show();
                            mCtx.startActivity(new Intent(mCtx, payment1.class));
                        }


                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Toast.makeText(mCtx, error.toString(), Toast.LENGTH_SHORT).show();
                    }
                }) {
            @Override
            protected Map<String, String> getParams() {
                Map<String, String> m = new HashMap<>();
                m.put("userid", userid);
                m.put("username",username);
                m.put("userphone",phone);
                m.put("sellerid","null");
                m.put("sellername","null");
                m.put("sellerphone","null");
                m.put("product_id",id);
                m.put("product_name",pname);
                m.put("product_price",amount);
                m.put("product_quantity",qn);
                m.put("product_image",image);
                m.put("gtotal","null");
                m.put("bdate",bdate);
                m.put("btime",btime);
                m.put("ulocation",location);


                return m;
            }
        };

        RequestQueue q = Volley.newRequestQueue(mCtx);
        q.add(s);


    }




    @Override
    public int getItemCount() {
        return dataModelArrayList.size();
    }





    class MyViewHolder extends RecyclerView.ViewHolder{

        TextView cname,cprice,cq;
         ImageView img;
         Button button;
         CardView card;
        public MyViewHolder(View itemView) {
            super(itemView);
            img = itemView.findViewById(R.id.pimage);
            cname= itemView.findViewById(R.id.cname);
            cprice = itemView.findViewById(R.id.cprice);
            card = itemView.findViewById(R.id.card);
            cq = itemView.findViewById(R.id.cdescription);
            button=itemView.findViewById(R.id.order);
            // location=itemView.findViewById(R.id.loc);

        }

        }

}

package com.example.Furniture.Tutor.Request;

import android.content.Context;
import android.telephony.SmsManager;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.example.Furniture.Config;
import com.example.Furniture.R;
import com.example.Furniture.Tutor.TutorSession;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class RequestAdapter extends RecyclerView.Adapter<RequestAdapter.MyViewHolder> {
    private LayoutInflater inflater;
    private ArrayList<RequestModel> dataModelArrayList;
    Context c;

    public RequestAdapter(Context ctx, ArrayList<RequestModel> dataModelArrayList) {
        c = ctx;
        inflater = LayoutInflater.from(ctx);
        this.dataModelArrayList = dataModelArrayList;
    }

    @NonNull
    @Override
    public RequestAdapter.MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = inflater.inflate(R.layout.request_item, parent, false);
        RequestAdapter.MyViewHolder holder = new RequestAdapter.MyViewHolder(view);
        return holder;
    }

    @Override
    public void onBindViewHolder(@NonNull RequestAdapter.MyViewHolder holder, int position) {
        final RequestModel model = dataModelArrayList.get(position);
        holder.username.setText(dataModelArrayList.get(position).getUsername());
        holder.userphone.setText(dataModelArrayList.get(position).getUserphone());
        holder.usercourse.setText(dataModelArrayList.get(position).getUsercourse());
        holder.userfee.setText(dataModelArrayList.get(position).getUserfee());


        holder.confirm.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                confirm(model.userphone,model.getUsercourse(),model.getUsername());
            }
        });



        holder.reject.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                reject(model.userphone,model.getUsercourse(),model.getUsername());
            }
        });

    }

    private void reject(String userphone,String course,String username) {
        String tutor_id;
        HashMap<String, String> user = new TutorSession(c).getUserDetails();
        tutor_id = user.get("id");

        final String[] status = new String[1];
        final String[] message = new String[1];
        String url = Config.baseURL + "reject.php";
        String re = "reject";

        StringRequest s = new StringRequest(Request.Method.POST, url,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        try {
//                            Toast.makeText(c, response, Toast.LENGTH_SHORT).show();
                            JSONObject c = new JSONObject(response);
                            status[0] = c.getString("status");
                            message[0] = c.getString("message");
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                        if (status.equals("1")) {
                            Toast.makeText(c, message[0], Toast.LENGTH_SHORT).show();
//                            sendOTP2(userphone);

//                            c.startActivity(new Intent(c,.class));
//                            ((Activity)c).finish();
                        }
                        else{
                            Toast.makeText(c, message[0], Toast.LENGTH_SHORT).show();

                        }
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Toast.makeText(c, error.toString(), Toast.LENGTH_SHORT).show();
                    }
                }) {
            @Override
            protected Map<String, String> getParams() {
                Map<String, String> m = new HashMap<>();
                m.put("tutor_id", tutor_id);
                m.put("status", re);
                m.put("usercourse", course);
                m.put("username", username);

                return m;
            }
        };

        RequestQueue q = Volley.newRequestQueue(c);
        q.add(s);

    }

    private void sendOTP2(String userphone) {
        String msg = "Welcome to craftmania application your admission request is rejected by some issues";

        SmsManager sms = SmsManager.getDefault();
        sms.sendTextMessage(userphone, null, msg, null, null);

//        Intent i = new Intent(ConfirmBuyActivity.this, OTPActivity.class);
//        i.putExtra("otp", Integer.toString(otp));
//        i.putExtra("phone", phone);
//        startActivity(i);
//        finish();
    }


    private void confirm(String userphone,String course,String username) {
        String tutor_id;
        HashMap<String, String> user = new TutorSession(c).getUserDetails();
        tutor_id = user.get("id");

        final String[] status = new String[1];
        final String[] message = new String[1];
        String url = Config.baseURL + "updateRequest.php";
        String re = "confirm";

        StringRequest s = new StringRequest(Request.Method.POST, url,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        try {
//                            Toast.makeText(c, response, Toast.LENGTH_SHORT).show();
                            JSONObject c = new JSONObject(response);
                            status[0] = c.getString("status");
                            message[0] = c.getString("message");
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                        if (status[0].equals("1")) {
                            Toast.makeText(c, message[0], Toast.LENGTH_SHORT).show();
                        }
                        else{
                            Toast.makeText(c, message[0], Toast.LENGTH_SHORT).show();

                        }
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Toast.makeText(c, error.toString(), Toast.LENGTH_SHORT).show();
                    }
                }) {
            @Override
            protected Map<String, String> getParams() {
                Map<String, String> m = new HashMap<>();
                m.put("tutor_id", tutor_id);
                m.put("status", re);
                m.put("usercourse", course);
                m.put("username", username);

                return m;
            }
        };

        RequestQueue q = Volley.newRequestQueue(c);
        q.add(s);

    }

    private void sendOTP(String userphone) {
        String msg = "Welcome to craftmania application your admission request is confirmed";

        SmsManager sms = SmsManager.getDefault();
        sms.sendTextMessage(userphone, null, msg, null, null);

//        Intent i = new Intent(ConfirmBuyActivity.this, OTPActivity.class);
//        i.putExtra("otp", Integer.toString(otp));
//        i.putExtra("phone", phone);
//        startActivity(i);
//        finish();
    }




    @Override
    public int getItemCount() {
        return dataModelArrayList.size();
    }

    public class MyViewHolder extends RecyclerView.ViewHolder {
        TextView username, userphone, usercourse, userfee;
        CardView card;
        Button confirm, reject;


        public MyViewHolder(@NonNull View itemView) {
            super(itemView);
            username = itemView.findViewById(R.id.username);
            userphone = itemView.findViewById(R.id.userphone);
            usercourse = itemView.findViewById(R.id.usercourse);
            card = itemView.findViewById(R.id.card);
            userfee = itemView.findViewById(R.id.userfee);
            confirm = itemView.findViewById(R.id.confirm);
            reject = itemView.findViewById(R.id.reject);



        }
    }
}

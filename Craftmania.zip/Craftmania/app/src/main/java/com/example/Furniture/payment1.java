package com.example.Furniture;

import androidx.appcompat.app.AppCompatActivity;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.example.Furniture.User.PaymentActivity;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

public class payment1 extends AppCompatActivity {
    TextView t1;
    RadioGroup r1;
    Button cash, online;
    String rb,status,error,userid,pid,sphone;
    LinearLayout layout1;
    RadioButton radioButton;
    private RequestQueue rQueue;
    private static ProgressDialog mProgressDialog;
    String url1=Config.baseURL+"update_screen.php";
    String url2=Config.baseURL+"updatecash.php";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_payment1);
        t1 = findViewById(R.id.phone1);
        r1 = findViewById(R.id.radioGroup);
        cash = findViewById(R.id.cash);
        online = findViewById(R.id.onpay);
        layout1 = findViewById(R.id.linear1);

        HashMap<String,String>user=new Session(getApplicationContext()).getUserDetails();
        userid=user.get("id");

        Intent i=getIntent();
        pid=i.getStringExtra("pid");
        sphone=i.getStringExtra("seller");
        Toast.makeText(this, pid, Toast.LENGTH_SHORT).show();
        t1.setText(sphone);


        cash.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                c();
            }
        });
        online.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                o();
            }
        });


    }

    private void o() {
        StringRequest request = new StringRequest(Request.Method.POST,url1,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
//                        loader.setVisibility(View.INVISIBLE);

                        try {
//                    Toast.makeText(OptionActivity.this, response, Toast.LENGTH_SHORT).show();
                            JSONObject jsnb = new JSONObject(response);
                            status = jsnb.getString("status");
                            error = jsnb.getString("message");


                        } catch (JSONException e) {
                            e.printStackTrace();
                        }

                        if ("0".equals(status)) {
                            Toast.makeText(payment1.this, error, Toast.LENGTH_SHORT).show();
                        } else {
                            Toast.makeText(payment1.this, " Successfull", Toast.LENGTH_SHORT).show();
                            Intent i = new Intent(payment1.this, PaymentActivity.class);
                            startActivity(i);
                            finish();
                        }
//
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
//                        loader.setVisibility(View.INVISIBLE);
                        Toast.makeText(payment1.this, error.toString(), Toast.LENGTH_SHORT).show();
                    }
                }) {
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                Map<String, String> params = new HashMap<>();
                params.put("mode", rb);
                params.put("userid",userid);
                params.put("pid",pid);
                return params;
            }
        };
        RequestQueue queue = Volley.newRequestQueue(this);
        queue.add(request);


    }

    private void c() {
        int radioButtonID = r1.getCheckedRadioButtonId();
        RadioButton radioButton = (RadioButton) r1.findViewById(radioButtonID);
        rb = (String) radioButton.getText();

        if(rb.equals("Cash On Delivery")){
           cashsub();
        }
        else{
            cash.setVisibility(View.GONE);
            layout1.setVisibility(View.VISIBLE);
//            startActivity(new Intent(getApplicationContext(),PayActivity.class));
        }


    }

    private void cashsub() {
        StringRequest request = new StringRequest(Request.Method.POST,url2,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
//                        loader.setVisibility(View.INVISIBLE);

                        try {
//                    Toast.makeText(OptionActivity.this, response, Toast.LENGTH_SHORT).show();
                            JSONObject jsnb = new JSONObject(response);
                            status = jsnb.getString("status");
                            error = jsnb.getString("message");


                        } catch (JSONException e) {
                            e.printStackTrace();
                        }

                        if ("0".equals(status)) {
                            Toast.makeText(payment1.this, error, Toast.LENGTH_SHORT).show();
                        } else {
                            Toast.makeText(payment1.this, " Successfull", Toast.LENGTH_SHORT).show();
                            Intent i = new Intent(payment1.this, NavigationActivity.class);
                            startActivity(i);
                            finish();
                        }
//
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
//                        loader.setVisibility(View.INVISIBLE);
                        Toast.makeText(payment1.this, error.toString(), Toast.LENGTH_SHORT).show();
                    }
                }) {
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                Map<String, String> params = new HashMap<>();
                params.put("mode", rb);
                params.put("userid",userid);
                params.put("pid",pid);
                return params;
            }
        };

        RequestQueue queue = Volley.newRequestQueue(this);
        queue.add(request);

    }
}
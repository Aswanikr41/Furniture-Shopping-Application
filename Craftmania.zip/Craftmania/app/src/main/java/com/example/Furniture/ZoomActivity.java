package com.example.Furniture;

import android.content.Intent;
import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

import com.jsibbold.zoomage.ZoomageView;
import com.squareup.picasso.Picasso;

public class ZoomActivity extends AppCompatActivity {

    ZoomageView zoomageView;
    String image;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_zoom);

        Intent i = getIntent();
        image = i.getStringExtra("image");

        zoomageView = findViewById(R.id.zoom_image_view);

        Picasso.get().load(Config.imageURL + image).into(zoomageView);

    }
}

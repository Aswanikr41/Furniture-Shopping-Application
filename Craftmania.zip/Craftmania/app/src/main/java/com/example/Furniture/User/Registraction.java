package com.example.Furniture.User;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.example.Furniture.Config;
import com.example.Furniture.OptionActivity;
import com.example.Furniture.R;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Registraction extends AppCompatActivity {

    EditText UserName,MobileNumber,Emailid,PassWord,location;
    Button register;
    String url= Config.baseURL+"registerer.php";
    String status,error,type;

    String U,M,E,P,locs;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_registraction);
        UserName=findViewById(R.id.userreg);
        MobileNumber=findViewById(R.id.phonereg);
        Emailid=findViewById(R.id.emailreg);
        PassWord=findViewById(R.id.passreg);
        register=findViewById(R.id.buttonreg);
        location=findViewById(R.id.location);

        Intent intent=getIntent();
        type=intent.getStringExtra("User");
        register.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                register();
            }
        });
    }
    private void register(){

        U=UserName.getText().toString();
        M=MobileNumber.getText().toString();
        E=Emailid.getText().toString();
        P=PassWord.getText().toString();
        locs=location.getText().toString();

        if (P.isEmpty() || P.length() < 6) {
            PassWord.setError("Password cannot be less than 6 characters!");
        }
        if (TextUtils.isEmpty(U)){
            UserName.setError("Please enter username");
            UserName.requestFocus();
            return;
        }
        else if(TextUtils.isEmpty(M)){
            MobileNumber.setError("Please type your mobile number");
            MobileNumber.requestFocus();
            return;
        }
        else if(!isPhoneValid(M))
        {
            MobileNumber.setError("Invalid number");
            MobileNumber.requestFocus();
            return;
        }
        else if (TextUtils.isEmpty(E)){
            Emailid.setError("Please enter your email id");
            Emailid.requestFocus();
            return;
        }
        else if(!isEmailValid(E)){
            Emailid.setError("Invalid email");
            Emailid.requestFocus();
            return;
        }
        else if (TextUtils.isEmpty(locs)){
            location.setError("Please type your location");
            location.requestFocus();
            return;
        }
        else if (TextUtils.isEmpty(P)){
            PassWord.setError("Please type your password");
            PassWord.requestFocus();
            return;
        }
        StringRequest str=new StringRequest(Request.Method.POST, url, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {

               // Toast.makeText(Registraction.this, response, Toast.LENGTH_SHORT).show();

                try {
                    JSONObject jsnb=new JSONObject(response);
                    status=jsnb.getString("StatusID");
                    error=jsnb.getString("Error");

                } catch (JSONException e) {
                    e.printStackTrace();
                }

                if ("0".equals(status))
                {
                    Toast.makeText(Registraction.this,error,Toast.LENGTH_SHORT).show();
                }
                else{
                    Toast.makeText(Registraction.this,"Registration successfull",Toast.LENGTH_SHORT).show();
                    Intent i=new Intent(Registraction.this, OptionActivity.class);
                    startActivity(i);
                }

            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {

                Toast.makeText(Registraction.this,error.toString(),Toast.LENGTH_SHORT).show();

            }
        })
        {
            @Override
            protected Map<String, String> getParams() {
                Map<String, String> params = new HashMap<>();

                params.put("username", U);
                params.put("Mobile_number", M);
                params.put("Email_id", E);
                params.put("password", P);
                params.put("location", locs);
                params.put("type", type);
                return params;
            }
        };
        RequestQueue rq= Volley.newRequestQueue(this);
        rq.add(str);

    }
    //regex
    public static boolean isPhoneValid(String s) {
        Pattern p = Pattern.compile("(0/91)?[6-9][0-9]{9}");
        Matcher m = p.matcher(s);
        return (m.find() && m.group().equals(s));
    }

    public static boolean isEmailValid(String email) {
        String emailRegex = "^[a-zA-Z0-9_+&*-]+(?:\\."+
                "[a-zA-Z0-9_+&*-]+)*@" +
                "(?:[a-zA-Z0-9-]+\\.)+[a-z" +
                "A-Z]{2,7}$";

        Pattern pat = Pattern.compile(emailRegex);
        return pat.matcher(email).matches();
    }
    public boolean isValidPassword(final String password) {

        Pattern pattern;
        Matcher matcher;

        final String PASSWORD_PATTERN = ("^" +
                //"(?=.*[0-9])" +         //at least 1 digit
                //"(?=.*[a-z])" +         //at least 1 lower case letter
                //"(?=.*[A-Z])" +         //at least 1 upper case letter
                "(?=.*[a-zA-Z])" +      //any letter
                "(?=.*[@#$%^&+=])" +    //at least 1 special character
                "(?=\\S+$)" +           //no white spaces
                ".{4,}" +               //at least 4 characters
                "$");

        pattern = Pattern.compile(PASSWORD_PATTERN);
        matcher = pattern.matcher(password);

        return matcher.matches();
    }


}
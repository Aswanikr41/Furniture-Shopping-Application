package com.example.Furniture.productfeed;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.Filter;
import android.widget.Filterable;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.Furniture.Config;
import com.example.Furniture.R;
import com.squareup.picasso.Picasso;

import java.util.ArrayList;

public class proAdapter extends RecyclerView.Adapter<proAdapter.MyViewHolder> implements Filterable {

    private LayoutInflater inflater;
    private ArrayList<proModel> dataModelArrayList;
    private Context c;

    public proAdapter(Context ctx, ArrayList<proModel> dataModelArrayList){
        c = ctx;
        inflater = LayoutInflater.from(c);
        this.dataModelArrayList = dataModelArrayList;
    }


    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = inflater.inflate(R.layout.flist, parent, false);
        MyViewHolder holder = new MyViewHolder(view);
        return holder;
    }


    @Override
    public void onBindViewHolder(@NonNull MyViewHolder holder, final int position) {
        final proModel product = dataModelArrayList.get(position);

        holder.fname.setText("Craftname: "+product.getProduct_name());
        holder.frating.setText("Rating Value : "+product.getRatingvalue());
        holder.fdes.setText("Feedback : "+product.getFeedback());

            Picasso.get().load(Config.imageURL +product.getProduct_image()).into(holder.imageView);


    }




    @Override
    public int getItemCount() {
        return dataModelArrayList.size();
    }

    @Override
    public Filter getFilter() {
        return null;
    }


    class MyViewHolder extends RecyclerView.ViewHolder{

        TextView fname,fdes,frating;
        ImageView imageView;
        Button remove;

        public MyViewHolder(View itemView) {
            super(itemView);
            imageView=itemView.findViewById(R.id.fimage);
            fname=itemView.findViewById(R.id.fname);
            fdes = itemView.findViewById(R.id.fdes);
            frating = itemView.findViewById(R.id.frating);
        }
    }
}

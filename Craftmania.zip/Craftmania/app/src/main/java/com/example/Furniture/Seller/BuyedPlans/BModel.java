package com.example.Furniture.Seller.BuyedPlans;

public class BModel {
String id,product_name,product_price,product_quantity,product_image,username,userphone,userid,gtotal,
        bdate,btime,status,sellerid,sellername,sellerphone,ulocation,mode,screenshot;

public BModel(String id, String product_name, String product_price, String product_quantity, String product_image, String username, String userphone,
              String userid, String gtotal, String bdate, String btime, String status, String sellerid, String sellername, String sellerphone,String ulocation,String mode,String screenshot) {
        this.id = id;
        this.product_name = product_name;
        this.product_price = product_price;
        this.product_quantity = product_quantity;
        this.product_image = product_image;
        this.username = username;
        this.userphone = userphone;
        this.userid = userid;
        this.gtotal = gtotal;
        this.bdate = bdate;
        this.btime = btime;
        this.status = status;
        this.sellerid = sellerid;
        this.sellername = sellername;
        this.sellerphone = sellerphone;
        this.ulocation = ulocation;
        this.mode = mode;
        this.screenshot = screenshot;
    }

    public String getId() {
        return id;
    }

    public String getProduct_name() {
        return product_name;
    }

    public String getProduct_price() {
        return product_price;
    }

    public String getProduct_quantity() {
        return product_quantity;
    }

    public String getProduct_image() {
        return product_image;
    }

    public String getUsername() {
        return username;
    }

    public String getUserphone() {
        return userphone;
    }

    public String getUserid() {
        return userid;
    }

    public String getGtotal() {
        return gtotal;
    }

    public String getBdate() {
        return bdate;
    }

    public String getBtime() {
        return btime;
    }

    public String getStatus() {
        return status;
    }

    public String getSellerid() {
        return sellerid;
    }

    public String getSellername() {
        return sellername;
    }

    public String getSellerphone() {
        return sellerphone;
    }

    public String getUlocation() {
        return ulocation;
    }

    public String getMode() {
        return mode;
    }

    public String getScreenshot() {
        return screenshot;
    }
}
package com.example.Furniture.Tutor.fee;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.telephony.SmsManager;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.example.Furniture.Config;
import com.example.Furniture.PayActivity;
import com.example.Furniture.R;
import com.example.Furniture.Session;
import com.example.Furniture.User.Toolvideo.VideoList;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class feeAdapter extends RecyclerView.Adapter<feeAdapter.MyViewHolder> {
    private LayoutInflater inflater;
    private ArrayList<feeModel> dataModelArrayList;
    Context c;
    String phone, name, tutor_id;

    public feeAdapter(Context ctx, ArrayList<feeModel> dataModelArrayList, String phone, String name, String tutor_id) {
        c = ctx;
        inflater = LayoutInflater.from(ctx);
        this.dataModelArrayList = dataModelArrayList;
        this.phone = phone;
        this.name = name;
        this.tutor_id = tutor_id;
    }

    @NonNull
    @Override


    public feeAdapter.MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = inflater.inflate(R.layout.fee_item, parent, false);
        feeAdapter.MyViewHolder holder = new feeAdapter.MyViewHolder(view);
        return holder;
    }

    @Override
    public void onBindViewHolder(@NonNull MyViewHolder holder, @SuppressLint("RecyclerView") int position) {
        final feeModel model = dataModelArrayList.get(position);
        holder.cname.setText("CourseName : " +dataModelArrayList.get(position).getCoursename());
        holder.cduration.setText("Duration: "+ dataModelArrayList.get(position).getDuration());
        holder.camount.setText("Fees :"+ dataModelArrayList.get(position).getFee());
        holder.tnumber.setText("Contact No: "+ phone);
        holder.tname.setText("Name: " + name);



        fetching(holder,position,model.getTutorid(),model.getCoursename());


        holder.pay.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

//                pay(holder,model.getFee());
                Intent i=new Intent(c, PayActivity.class);
                i.putExtra("amount",model.getFee());
                i.putExtra("course",model.getCoursename());
                i.putExtra("tutor",model.getTutorid());
                i.putExtra("tphone",phone);
                c.startActivity(i);
            }
        });


        holder.call.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Intent.ACTION_DIAL);
                intent.setData(Uri.parse("tel:" + phone));
                c.startActivity(intent);
            }
        });

        holder.request.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                request(model.getCoursename(), model.getFee(),holder);
            }
        });

        holder.video.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i=new Intent(c, VideoList.class);
                i.putExtra("tutor_id",model.getTutorid());
                c.startActivity(i);
            }
        });

    }

    private void fetching(MyViewHolder holder, int position,String tutor_id,String course) {
        String userid;
        final String[] statuses = new String[1];
        final String[] message = new String[1];
        String url=Config.baseURL+"feestatus.php";
        HashMap<String, String> user = new Session(c).getUserDetails();
        userid=user.get("id");
        final String[] status = new String[1];

        StringRequest s = new StringRequest(Request.Method.POST, url,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        try {
//                            Toast.makeText(c, response, Toast.LENGTH_SHORT).show();

                            JSONObject c = new JSONObject(response);
                            status[0] = c.getString("status");
                            statuses[0] = c.getString("statuse");
                            message[0] = c.getString("message");
//                            holder.display.setText(statuses[0]);

                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                        if (statuses[0].equals("1")) {
//                            /Toast.makeText(c, message[0], Toast.LENGTH_SHORT).show();

                            if(status[0].equals("request")){
                                holder.request.setVisibility(View.GONE);
                                holder.display.setVisibility(View.VISIBLE);
                            }
                            else if(status[0].equals("confirm")){
                                Toast.makeText(c, "Your request is confirmed you can pay now", Toast.LENGTH_SHORT).show();
                                 holder.request.setVisibility(View.GONE);
                                 holder.pay.setVisibility(View.VISIBLE);

                             }
                            else if(status[0].equals("paid")){
                                Toast.makeText(c, "Your are already paid for this course", Toast.LENGTH_SHORT).show();
                                holder.request.setVisibility(View.GONE);
                                holder.pay.setVisibility(View.GONE);

                            }
                        }
                        else {
//                            Toast.makeText(c, "error", Toast.LENGTH_SHORT).show();
                        }
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Toast.makeText(c, error.toString(), Toast.LENGTH_SHORT).show();
                    }
                }) {
            @Override
            protected Map<String, String> getParams() {
                Map<String, String> m = new HashMap<>();
                m.put("userid", userid);
                m.put("tutor_id", tutor_id);
                m.put("usercourse", course);

                return m;
            }
        };

        RequestQueue q = Volley.newRequestQueue(c);
        q.add(s);


    }


    private void request(String coursename, String fee, MyViewHolder holder) {
        String username, userphone, userid;
        HashMap<String, String> user = new Session(c).getUserDetails();
        username = user.get("username");
        userphone = user.get("mobilenumber");
        userid = user.get("id");
        final String[] status = new String[1];
        final String[] message = new String[1];

        String url = Config.baseURL + "feerequestUpdate.php";
        String re = "request";

        StringRequest s = new StringRequest(Request.Method.POST, url,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        try {
//                            Toast.makeText(c, response, Toast.LENGTH_SHORT).show();

                            JSONObject c = new JSONObject(response);
                            status[0] = c.getString("status");
                            message[0] = c.getString("message");

                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                        if (status[0].equals("1")) {
                            Toast.makeText(c, "Added", Toast.LENGTH_SHORT).show();
                            holder.request.setVisibility(View.GONE);
                            holder.display.setVisibility(View.VISIBLE);

                        }
                        else {
                            Toast.makeText(c, message[0], Toast.LENGTH_SHORT).show();
                        }
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Toast.makeText(c, error.toString(), Toast.LENGTH_SHORT).show();
                    }
                }) {
            @Override
            protected Map<String, String> getParams() {
                Map<String, String> m = new HashMap<>();
                m.put("userid", userid);
                m.put("username", username);
                m.put("userphone", userphone);
                m.put("usercourse", coursename);
                m.put("userfee", fee);
                m.put("tutor_id", tutor_id);
                m.put("status", re);
                return m;
            }
        };

        RequestQueue q = Volley.newRequestQueue(c);
        q.add(s);

    }






    @Override
    public int getItemCount() {
        return dataModelArrayList.size();
    }

    public class MyViewHolder extends RecyclerView.ViewHolder {
        TextView cname, camount, cduration,tname,tnumber;
        LinearLayout card;
        Button request,call,pay,video;
        TextView display;


        public MyViewHolder(@NonNull View itemView) {
            super(itemView);
            cname = itemView.findViewById(R.id.cname);
            camount = itemView.findViewById(R.id.camount);
            cduration = itemView.findViewById(R.id.cduration);
            card = itemView.findViewById(R.id.card);
            request = itemView.findViewById(R.id.request);
            call = itemView.findViewById(R.id.call);
            tname = itemView.findViewById(R.id.tname);
            tnumber = itemView.findViewById(R.id.tnumber);
            pay = itemView.findViewById(R.id.pay);
            display = itemView.findViewById(R.id.display);
            video = itemView.findViewById(R.id.video);

        }
    }



    public void sendOTP() {

        String msg = "Welcome to craftmania application " + name + " has requseted for admission";

        SmsManager sms = SmsManager.getDefault();
        sms.sendTextMessage(phone, null, msg, null, null);

//        Intent i = new Intent(ConfirmBuyActivity.this, OTPActivity.class);
//        i.putExtra("otp", Integer.toString(otp));
//        i.putExtra("phone", phone);
//        startActivity(i);
//        finish();
    }


    // Function to check and request permission.



}

package com.example.Furniture.Seller;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;

import com.example.Furniture.Config;
import com.example.Furniture.R;
import com.squareup.picasso.Picasso;

import java.util.ArrayList;
import java.util.List;

public class CustomAdapter extends RecyclerView.Adapter<CustomAdapter.MyLove> {
    Context c;
    private List<CustomModel> dataModelArrayList;

    private LayoutInflater inflater;

    public CustomAdapter(Context mCtx, ArrayList<CustomModel> dataModelArrayList) {
        this.c=mCtx;
        this.dataModelArrayList = dataModelArrayList;
        inflater = LayoutInflater.from(mCtx);

    }

    @NonNull
    @Override
    public CustomAdapter.MyLove onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = inflater.inflate(R.layout.custom_item, parent, false);
        CustomAdapter.MyLove holder = new CustomAdapter.MyLove(view);
        return holder;
    }

    @Override
    public void onBindViewHolder(@NonNull CustomAdapter.MyLove holder, int position) {
holder.itemname.setText("Item Name : " + dataModelArrayList.get(position).getItemname());
holder.quantiy.setText("Quantity Needed : " + dataModelArrayList.get(position).getQn());
holder.buget.setText("Budget : " + dataModelArrayList.get(position).getMb());
        Picasso.get().load(Config.imageURL+dataModelArrayList.get(position).getImage()).into(holder.img);

        holder.cardView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                CustomModel p = dataModelArrayList.get(position);

                Intent i = new Intent(c, ViewCustom.class);
                i.putExtra("id", p.getId());
                i.putExtra("userid", p.getUserid());
                i.putExtra("username", p.getUsername());
                i.putExtra("phone", p.getPhone());
                i.putExtra("location", p.getLocation());
                i.putExtra("mb", p.getMb());
                i.putExtra("qn", p.getQn());
                i.putExtra("len", p.getLen());
                i.putExtra("wid", p.getWid());
                i.putExtra("des", p.getDes());
                i.putExtra("img", p.getImage());
                i.putExtra("itemname", p.getItemname());
i.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                c.startActivity(i);
            }
        });
    }



    @Override
    public int getItemCount() {
        return dataModelArrayList.size();
    }

    public class MyLove extends RecyclerView.ViewHolder {
        TextView quantiy,buget,itemname;
        ImageView img;
        CardView cardView;
        public MyLove(@NonNull View itemView) {
            super(itemView);
            buget=itemView.findViewById(R.id.mbudget);
            quantiy=itemView.findViewById(R.id.Quantity);
            img=itemView.findViewById(R.id.pimage);
            cardView=itemView.findViewById(R.id.cardcustom);
            itemname=itemView.findViewById(R.id.itname);

        }
    }
}

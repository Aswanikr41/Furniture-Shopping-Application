package com.example.Furniture.Tutor;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.example.Furniture.Config;
import com.example.Furniture.R;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

public class Addfee extends AppCompatActivity {
    EditText coname,fees,description,duration;
    Button add;
    String conames,fee,des,durations;
    String status;
    String message,tutor_id;
    String url= Config.baseURL+"add_fee.php";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_addfee);
        coname=findViewById(R.id.CourseName);
        fees=findViewById(R.id.fee);
        description=findViewById(R.id.cdescription);
        duration=findViewById(R.id.duration);
        add=findViewById(R.id.add);
        HashMap<String,String> user =new TutorSession(getApplicationContext()).getUserDetails();
        tutor_id=user.get("id");


        add.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                addfee();
            }
        });

    }

    private void addfee() {
        conames=coname.getText().toString();
        fee=fees.getText().toString();
        des=description.getText().toString();
        durations=duration.getText().toString();

        StringRequest s = new StringRequest(Request.Method.POST, url,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
//                        Toast.makeText(getActivity(), response, Toast.LENGTH_SHORT).show();

                        try {
                            JSONObject c = new JSONObject(response);
                            status = c.getString("status");
                            message = c.getString("message");

                            if (status.equals("1")) {
                                Toast.makeText(getApplicationContext(), "Fee added successfully", Toast.LENGTH_SHORT).show();
                                startActivity(new Intent(getApplicationContext(), TutorActivity.class));

                            }
                            else {
                                Toast.makeText(getApplicationContext(), message, Toast.LENGTH_LONG).show();
                            }

                        } catch (JSONException e) {
                            e.printStackTrace();
                        }

                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Toast.makeText(getApplicationContext(), error.toString(), Toast.LENGTH_LONG).show();
                    }
                }) {
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                Map<String, String> m = new HashMap<>();
                m.put("tutor_id", tutor_id);
                m.put("coursename", conames);
                m.put("fee", fee);
                m.put("description", des);
                m.put("duration", durations);
                return m;
            }
        };
        RequestQueue q = Volley.newRequestQueue(getApplicationContext());
        q.add(s);
    }

}

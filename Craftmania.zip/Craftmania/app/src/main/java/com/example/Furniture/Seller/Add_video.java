package com.example.Furniture.Seller;

import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.example.Furniture.Config;
import com.example.Furniture.R;


import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

public class Add_video extends AppCompatActivity {
EditText desc,urls;
Button btn;
String url= Config.baseURL+"video.php";
String statusid,error;
String name,type;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_video);
        desc=findViewById(R.id.plan);
        urls=findViewById(R.id.url);
        btn=findViewById(R.id.btnUpload);
btn.setOnClickListener(new View.OnClickListener() {
    @Override
    public void onClick(View v) {
        upload();
    }
});
    }

    private void upload() {

        name = desc.getText().toString();
        type = urls.getText().toString();

        if (TextUtils.isEmpty(name)) {
            desc.setError("enter plan ideas");
            desc.requestFocus();
            return;
        }

        if (TextUtils.isEmpty(type)) {
            urls.setError("Copy video url");
            urls.requestFocus();
            return;
        }

        StringRequest s=new StringRequest(Request.Method.POST, url,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        try {
                            JSONObject j=new JSONObject(response);
                            statusid=j.getString("Status");
                            error=j.getString("Error");
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                        if (statusid.equals("0"))
                        {
                            Toast.makeText(Add_video.this, error, Toast.LENGTH_SHORT).show();
                        }
                        else
                        {
                            Toast.makeText(Add_video.this, "Upload Successfully", Toast.LENGTH_SHORT).show();
//                            Intent i = new Intent(getContext(), UploadLocationActivity.class);
//                            i.putExtra("username", username);
//                            startActivity(i);
//                            finish();
                        }

                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        //progress.setVisibility(View.GONE);
                        Toast.makeText(Add_video.this, error.toString(), Toast.LENGTH_SHORT).show();

                    }
                }){
            @Override
            protected Map<String, String> getParams()  {
                Map<String,String> m=new HashMap<>();
                m.put("plan_idea",name);
                m.put("url",type);
                return m;

            }
        };
        RequestQueue r= Volley.newRequestQueue(Add_video.this);
        r.add(s);


    }
    }

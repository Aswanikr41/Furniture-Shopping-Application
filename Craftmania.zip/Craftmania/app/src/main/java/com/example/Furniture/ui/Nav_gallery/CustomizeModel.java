package com.example.Furniture.ui.Nav_gallery;

public class CustomizeModel {
    String id,pname,image,amount,qn;

    public CustomizeModel(String id, String pname, String image, String amount, String qn) {
        this.id = id;
        this.pname = pname;
        this.image = image;
        this.amount = amount;
        this.qn = qn;
    }

    public String getId() {
        return id;
    }

    public String getPname() {
        return pname;
    }

    public String getImage() {
        return image;
    }

    public String getAmount() {
        return amount;
    }

    public String getQn() {
        return qn;
    }
}
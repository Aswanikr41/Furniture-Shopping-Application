package com.example.Furniture.Seller;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import com.example.Furniture.Config;
import com.example.Furniture.R;
import com.squareup.picasso.Picasso;

import org.json.JSONException;
import org.json.JSONObject;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

public class ViewCustom extends AppCompatActivity {
    TextView sellname, sellphone, cname, stock, cprice, cdes, clocation,prevsatus;
    String cnames, cprices, amount, cstock, sellnames, sellphones;
    String userid, id, username, email, phone, imgs, status, message, links, locs,modes1,scimg;
    ImageView img,screenimg;
    Button sub;
    Spinner spinner;
    String[]stat={"Select status","Order confirmed","Order Rejected"};
    String sid,bdate,btime,spindata,userids,usernames,userphns,prevsts;
    TextView tamount,modes;
    String url1=Config.baseURL+"updatecustomdata.php";
EditText ttamount,reason;
String t,r,item;
    @SuppressLint({"ResourceAsColor", "MissingInflatedId"})
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_view_custom);
        sellname = findViewById(R.id.name);
        sellphone = findViewById(R.id.phone);
        cname = findViewById(R.id.cname);
        cprice = findViewById(R.id.cprice);
        clocation = findViewById(R.id.loc);
        stock = findViewById(R.id.stock);
        img = findViewById(R.id.image);
        ttamount = findViewById(R.id.tamounts);
        reason = findViewById(R.id.reason);
        sub = findViewById(R.id.update);
        spinner = findViewById(R.id.sts);
        prevsatus = findViewById(R.id.previous);
        screenimg = findViewById(R.id.screenimage);
        modes = findViewById(R.id.mode);


        bdate = new SimpleDateFormat("dd/MM/yyyy", Locale.getDefault()).format(new Date());
        btime = new SimpleDateFormat("HH:mm:ss", Locale.getDefault()).format(new Date());



        HashMap<String, String> user = new SellerSession(ViewCustom.this).getUserDetails();
        userid = user.get("id");
        username = user.get("Username");
        phone = user.get("Mobile_number");
        //Toast.makeText(this, userid + username + phone + email, Toast.LENGTH_SHORT).show();

        Intent intent = getIntent();
        id = intent.getStringExtra("id");
        userids = intent.getStringExtra("userid");
        usernames = intent.getStringExtra("username");
        userphns = intent.getStringExtra("phone");

        cnames = intent.getStringExtra("itemname");
        cprices = intent.getStringExtra("mb");
        imgs = intent.getStringExtra("img");
        cstock = intent.getStringExtra("des");
        sid = intent.getStringExtra("sid");
        locs = intent.getStringExtra("location");



        String imageurl = Config.imageURL + imgs;
        Picasso.get().load(imageurl).into(img);



        sellname.setText(usernames + id);
        sellphone.setText(userphns);
        cname.setText(cnames);
        cprice.setText("Max Budget : " + cprices);
        stock.setText(cstock);
        clocation.setText(locs);


        sellphone.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                    Intent intent = new Intent(Intent.ACTION_DIAL);
                    intent.setData(Uri.parse("tel:" + userphns));
                    startActivity(intent);
            }
        });


        ArrayAdapter<String> adapter=new ArrayAdapter(getApplicationContext(),R.layout.support_simple_spinner_dropdown_item,stat);
        spinner.setAdapter(adapter);

        spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                if(spinner.getSelectedItem().equals("Order confirmed")){
                    ttamount.setVisibility(View.VISIBLE);
                }
                else if(spinner.getSelectedItem().equals("Order Rejected")){
                    ttamount.setVisibility(View.GONE);
                    reason.setVisibility(View.VISIBLE);
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });



        sub.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                adds();
            }
        });

    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.chat_menu, menu);

        return super.onCreateOptionsMenu(menu);
    }
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        //handle menu item clicks
        int id = item.getItemId();

        if (id == R.id.chat_menu) {
            watsapp();
        }
        return super.onOptionsItemSelected(item);
    }

    private void watsapp() {
        Uri mUri = Uri.parse("smsto:" + userphns);
        Intent mIntent = new Intent(Intent.ACTION_SENDTO, mUri);
        mIntent.setPackage("com.whatsapp");
        mIntent.putExtra("sms_body", "The text goes here");
        mIntent.putExtra("chat", true);
        startActivity(Intent.createChooser(mIntent, ""));
    }


    private void adds() {
        t=ttamount.getText().toString();
        r=reason.getText().toString();
        spindata=spinner.getSelectedItem().toString();


        StringRequest stringRequest = new StringRequest(Request.Method.POST, url1,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        try {
//                            Toast.makeText(getApplicationContext(), response, Toast.LENGTH_SHORT).show();
                            JSONObject c = new JSONObject(response);
                            status = c.getString("status");
                            message = c.getString("message");
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                        if (status.equals("1")) {
                            Toast.makeText(ViewCustom.this, "Status updated", Toast.LENGTH_SHORT).show();
                            startActivity(new Intent(getApplicationContext(), BottomActivity.class));
                            sms(spindata);
                        } else {
                            Toast.makeText(ViewCustom.this, "error", Toast.LENGTH_SHORT).show();
                        }
                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Toast.makeText(ViewCustom.this, error.toString(), Toast.LENGTH_SHORT).show();
            }
        }){
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                Map<String,String> map = new HashMap<>();
                map.put("userid",userids);
                map.put("status",spindata);
                map.put("amount",t);
                map.put("reason",r);
                map.put("customid",id);
                return map;
            }
        };
        RequestQueue requestQueue = Volley.newRequestQueue(this);
        requestQueue.add(stringRequest);

    }

    private void sms(String spindata) {
//        String msg="Sorry i can't take your booking right now because of"  + reason +  "So im reassign to " +"  " + username  +  "contact them " + assigned_phn ;
        SmsManager smsManager=SmsManager.getDefault();
        smsManager.sendTextMessage(userphns,null,spindata,null,null);
        Toast.makeText(ViewCustom.this,"Message Sent",Toast.LENGTH_LONG).show();

    }


}
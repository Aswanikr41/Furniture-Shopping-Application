package com.example.Furniture.User.wishlist;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.RetryPolicy;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.example.Furniture.Config;
import com.example.Furniture.NavigationActivity;
import com.example.Furniture.R;
import com.squareup.picasso.Picasso;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class UserWishListAdapter extends RecyclerView.Adapter<UserWishListAdapter.MyViewHolder> {
    private LayoutInflater inflater;
    private ArrayList<UserWishlistDataModel> dataModelArrayList;
    Context c;
    public UserWishListAdapter(Context ctx, ArrayList<UserWishlistDataModel> dataModelArrayList) {
        c = ctx;
        inflater = LayoutInflater.from(ctx);
        this.dataModelArrayList = dataModelArrayList;



    }



    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = inflater.inflate(R.layout.wish_item, parent, false);
        MyViewHolder holder = new MyViewHolder(view);

        return holder;
    }

    @Override
    public void onBindViewHolder(@NonNull MyViewHolder holder, int position) {

        final UserWishlistDataModel model = dataModelArrayList.get(position);
        holder.sqfeet.setText( dataModelArrayList.get(position).getCname());
        holder.budget.setText(dataModelArrayList.get(position).getCprice());
        if (!dataModelArrayList.get(position).getImage().equals("")) {
            Picasso.get().load(Config.imageURL + dataModelArrayList.get(position).getImage()).into(holder.img);
        }




        holder.btnremove.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                removeItem(model.getUserid(),model.getCname());
            }
        });

    }

    private void removeItem(final String user_id,String cname) {

        final String[] status = {""};
        final String url = Config.baseURL +  "deletewish.php";

        StringRequest s = new StringRequest(Request.Method.POST, url,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        try {
                            JSONObject c = new JSONObject(response);
                            status[0] = c.getString("StatusID");
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                        if (status[0].equals("1")) {
                            Toast.makeText(c, "Removed Successfully", Toast.LENGTH_SHORT).show();
                            c.startActivity(new Intent(c, NavigationActivity.class));
                            ((Activity)c).finish();
                        }
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Toast.makeText(c, error.toString(), Toast.LENGTH_SHORT).show();
                    }
                }) {
            @Override
            protected Map<String, String> getParams() {
                Map<String, String> m = new HashMap<>();
                m.put("cname", cname);
                m.put("userid", user_id);
                return m;
            }
        };

        s.setRetryPolicy(new RetryPolicy() {
            @Override
            public int getCurrentTimeout() {
                return 20000;
            }
            @Override
            public int getCurrentRetryCount() {
                return 20000;
            }
            @Override
            public void retry(VolleyError error) {
                Toast.makeText(c, error.toString(), Toast.LENGTH_SHORT).show();
            }
        });
        RequestQueue q = Volley.newRequestQueue(c);
        q.add(s);

    }

    @Override
    public int getItemCount() {
        return dataModelArrayList.size();
    }

    public class MyViewHolder extends RecyclerView.ViewHolder {

        TextView sqfeet,budget;
        ImageView img;
        CardView card;
        Button button,btnremove;
        public MyViewHolder(View itemView) {
            super(itemView);
            img = itemView.findViewById(R.id.pimage);
            sqfeet= itemView.findViewById(R.id.sqfeet);
            budget = itemView.findViewById(R.id.budget);
            card = itemView.findViewById(R.id.card);
//            button=itemView.findViewById(R.id.buys);
            btnremove=itemView.findViewById(R.id.remove);
        }
    }
}

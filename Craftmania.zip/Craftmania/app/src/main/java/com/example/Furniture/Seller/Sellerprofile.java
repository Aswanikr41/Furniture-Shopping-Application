package com.example.Furniture.Seller;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import com.example.Furniture.Config;
import com.example.Furniture.R;

import java.util.HashMap;

public class Sellerprofile extends AppCompatActivity {
    TextView fusername, femail, fphonenumber, fpassword,location;
    Button feditprofile, fhelp, fabout, flogout;
    String id,username, email_id, mobile_number, password,locations;
    String url = Config.baseURL+"editprofile.php";
    String status, error;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sellerprofile);
        fusername =findViewById(R.id.user);
        femail =findViewById(R.id.email);
        fphonenumber = findViewById(R.id.phone);
        feditprofile =findViewById(R.id.btnEdit);
        location =findViewById(R.id.location);

        HashMap<String, String> m = new SellerSession(getApplicationContext()).getUserDetails();
        username = m.get("Username");
        mobile_number = m.get("Mobile_number");
        email_id = m.get("Email");
        locations = m.get("location");

        fusername.setText(username);
        femail.setText(email_id);
        fphonenumber.setText(mobile_number);
        location.setText(locations);
        feditprofile.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i=new Intent(getApplicationContext(), EditProfile.class);
                startActivity(i);
            }
        });

    }

}
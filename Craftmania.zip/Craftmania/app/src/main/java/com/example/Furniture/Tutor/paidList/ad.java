package com.example.Furniture.Tutor.paidList;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.Furniture.Config;
import com.example.Furniture.R;
import com.squareup.picasso.Picasso;

import java.util.ArrayList;

public class ad extends RecyclerView.Adapter<ad.MyViewHolder> {
    private LayoutInflater inflater;
    private ArrayList<mo> dataModelArrayList;
    Context c;

    public ad(Context ctx, ArrayList<mo> dataModelArrayList) {
        c = ctx;
        inflater = LayoutInflater.from(ctx);
        this.dataModelArrayList = dataModelArrayList;
    }

    @NonNull
    @Override
    public ad.MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = inflater.inflate(R.layout.paidcard, parent, false);
        ad.MyViewHolder holder = new ad.MyViewHolder(view);
        return holder;
    }

    @Override
    public void onBindViewHolder(@NonNull ad.MyViewHolder holder, int position) {
        final mo product = dataModelArrayList.get(position);

        holder.name.setText("Name: " + product.getUsername());
        holder.phone.setText("Phone: " + product.getUserphone());
        holder.status.setText("Payment status:" +  product.getStatus());
        holder.am.setText("Paid amount: " + product.getAmount());
        Picasso.get().load(Config.imageURL+product.getScreenimg()).into(holder.img);
    }

    @Override
    public int getItemCount() {
        return dataModelArrayList.size();
    }


    class MyViewHolder extends RecyclerView.ViewHolder {
        TextView name, phone, status,am;
ImageView img;

        public MyViewHolder(@NonNull View itemView) {
            super(itemView);
            name = itemView.findViewById(R.id.name);
            phone = itemView.findViewById(R.id.phone);
            status = itemView.findViewById(R.id.status);
            am = itemView.findViewById(R.id.amount);
            img = itemView.findViewById(R.id.scimg);
        }
    }
}

package com.example.Furniture.User.view_buyed_items;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.Filter;
import android.widget.Filterable;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;

import com.example.Furniture.Config;
import com.example.Furniture.R;
import com.squareup.picasso.Picasso;

import java.util.ArrayList;

public class ItemsAdapter extends RecyclerView.Adapter<ItemsAdapter.MyViewHolder> implements Filterable {

    private LayoutInflater inflater;
    private ArrayList<ItemsDataModel> dataModelArrayList;
    private Context c;

    public ItemsAdapter(Context ctx, ArrayList<ItemsDataModel> dataModelArrayList){
        c = ctx;
        inflater = LayoutInflater.from(c);
        this.dataModelArrayList = dataModelArrayList;
    }


    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = inflater.inflate(R.layout.myplan, parent, false);
        MyViewHolder holder = new MyViewHolder(view);
        return holder;
    }


    @Override
    public void onBindViewHolder(@NonNull MyViewHolder holder, @SuppressLint("RecyclerView") final int position) {
        final ItemsDataModel product = dataModelArrayList.get(position);
        holder.prname.setText(dataModelArrayList.get(position).getProduct_name());
        holder.pprice.setText("Price: "+dataModelArrayList.get(position).getProduct_price());
        holder.pquantity.setText("Quantity: "+dataModelArrayList.get(position).getProduct_quantity());
        holder.username.setText("Username: "+dataModelArrayList.get(position).getUsername());
        if (!dataModelArrayList.get(position).getProduct_image().equals("")) {
            Picasso.get().load(Config.imageURL + dataModelArrayList.get(position).getProduct_image()).into(holder.imageView);
        }

        holder.rootLayout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ItemsDataModel p = dataModelArrayList.get(position);
                String id = p.getId();
                String name = p.getSellername();
                String phone = p.getSellerphone();
                String cname = p.getProduct_name();
                String cprice = p.getProduct_price();
                String im =   p.getProduct_image();
                String stock = p.getProduct_quantity();
                String sid = p.getSellerid();
                String uloc = p.getUlocation();
                String gtotal = p.getGtotal();
                String userid = p.getUserid();
                String username = p.getUsername();
                String userphn = p.getUserphone();
                String status = p.getStatus();

                Intent i = new Intent(c, Myorderdetails.class);
                i.putExtra("id", id);
                i.putExtra("sname", name);
                i.putExtra("sphone", phone);
                i.putExtra("cname", cname);
                i.putExtra("cprice", cprice);
                i.putExtra("cloc",uloc);
                i.putExtra("image", im);
                i.putExtra("stock", stock);
                i.putExtra("sid", sid);
                i.putExtra("gtotal", gtotal);
                i.putExtra("userid", userid);
                i.putExtra("username", username);
                i.putExtra("userphn", userphn);
                i.putExtra("status", status);
                Toast.makeText(c, status, Toast.LENGTH_SHORT).show();


                c.startActivity(i);
            }

        });

    }



    @Override
    public int getItemCount() {
        return dataModelArrayList.size();
    }

    @Override
    public Filter getFilter() {
        return null;
    }


    class MyViewHolder extends RecyclerView.ViewHolder{

        TextView prname,pprice,pquantity,username;
        ImageView imageView;
        CardView rootLayout;
        Button delete;

        public MyViewHolder(View itemView) {
            super(itemView);
            imageView=itemView.findViewById(R.id.ivImage);
            prname = itemView.findViewById(R.id.pname);
            pprice = itemView.findViewById(R.id.price);
            pquantity = itemView.findViewById(R.id.quantity);
            delete = itemView.findViewById(R.id.cancel);
            username = itemView.findViewById(R.id.username);
            rootLayout = itemView.findViewById(R.id.rootLayout);
        }
    }

}

package com.example.Furniture.ui.Southlist;

public class ProductListModel {
    private String id, type, foodname, foodprice,foodquantity,image,shopid;

    public ProductListModel(String id, String type, String foodname, String foodprice, String foodquantity, String image,String shopid) {
        this.id = id;
        this.type = type;
        this.foodname = foodname;
        this.foodprice = foodprice;
        this.foodquantity = foodquantity;
        this.image = image;
        this.shopid = shopid;
    }

    public String getId() {
        return id;
    }

    public String getType() {
        return type;
    }

    public String getFoodname() {
        return foodname;
    }

    public String getFoodprice() {
        return foodprice;
    }

    public String getFoodquantity() {
        return foodquantity;
    }

    public String getImage() {
        return image;
    }

    public String getShopid() {
        return shopid;
    }
}


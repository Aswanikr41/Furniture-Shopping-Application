package com.example.Furniture.User;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.example.Furniture.Config;
import com.example.Furniture.NavigationActivity;
import com.example.Furniture.R;
import com.example.Furniture.Session;


import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;


public class LoginActivity extends AppCompatActivity {
    EditText username, pword;
    TextView create,forgot;
    Button login;
    String status, error,id;
    String user, pass;
String url= Config.baseURL+"login.php";
String Username,Mobile_number,Email,location,tutor_id;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        username = findViewById(R.id.username);
        pword = findViewById(R.id.password);
        login = findViewById(R.id.button);
        create = findViewById(R.id.account);
//        forgot = findViewById(R.id.frgt);

//        forgot.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                Intent j = new Intent(LoginActivity.this, FrgtoneActivity.class);
//                startActivity(j);
////                finish();
//            }
//        });

        login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                register();
            }
        });
        create.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent j = new Intent(LoginActivity.this, Registraction.class);
                startActivity(j);
//                finish();
            }
        });
    }

   private void register() {
        user = username.getText().toString();
        pass =  pword.getText().toString();
        if (TextUtils.isEmpty(user)) {
            username.setError("please enter the mobile number");
            username.requestFocus();
            return;
        } else if (TextUtils.isEmpty(pass)) {
            pword.setError("please enter password");
            pword.requestFocus();
            return;
        }
        StringRequest str = new StringRequest(Request.Method.POST, url, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {

                try {
                    JSONObject jsnb = new JSONObject(response);
                    status = jsnb.getString("status");
                    error = jsnb.getString("message");
                    id=jsnb.getString("id");
                    Username=jsnb.getString("username");
                    Mobile_number=jsnb.getString("Mobile_number");
                    Email=jsnb.getString("Email_id");
                    location=jsnb.getString("location");
                    tutor_id=jsnb.getString("tutor_id");
                } catch (JSONException e) {
                    e.printStackTrace();
                }

                if ("0".equals(status)) {
                    Toast.makeText(LoginActivity.this, error, Toast.LENGTH_SHORT).show();
                } else {
                    Toast.makeText(LoginActivity.this, "Login Successfull", Toast.LENGTH_SHORT).show();
                    Intent i = new Intent(LoginActivity.this, NavigationActivity.class);
                    new Session(LoginActivity.this).createLoginSession(id,Username,Mobile_number,Email,location);
                    startActivity(i);
            }
            }

        },
                new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Toast.makeText(LoginActivity.this, error.toString(), Toast.LENGTH_SHORT).show();
            }
        }) {
            @Override
            protected Map<String, String> getParams()  {
                Map<String, String> params = new HashMap<>();
                params.put("Mobile_number",user);
                params.put("password", pass);
                return params;
            }
        };
        RequestQueue rq= Volley.newRequestQueue(this);
        rq.add(str);
    }


    //regex
    public static boolean isPhoneValid(String s) {
        Pattern p = Pattern.compile("(0/91)?[6-9][0-9]{9}");
        Matcher m = p.matcher(s);
        return (m.find() && m.group().equals(s));
    }

    public static boolean isEmailValid(String email) {
        String emailRegex = "^[a-zA-Z0-9_+&*-]+(?:\\."+
                "[a-zA-Z0-9_+&*-]+)*@" +
                "(?:[a-zA-Z0-9-]+\\.)+[a-z" +
                "A-Z]{2,7}$";

        Pattern pat = Pattern.compile(emailRegex);
        return pat.matcher(email).matches();
    }
    public boolean isValidPassword(final String password) {

        Pattern pattern;
        Matcher matcher;

        final String PASSWORD_PATTERN = ("^" +
                //"(?=.*[0-9])" +         //at least 1 digit
                //"(?=.*[a-z])" +         //at least 1 lower case letter
                //"(?=.*[A-Z])" +         //at least 1 upper case letter
                "(?=.*[a-zA-Z])" +      //any letter
                "(?=.*[@#$%^&+=])" +    //at least 1 special character
                "(?=\\S+$)" +           //no white spaces
                ".{4,}" +               //at least 4 characters
                "$");

        pattern = Pattern.compile(PASSWORD_PATTERN);
        matcher = pattern.matcher(password);

        return matcher.matches();
    }

}
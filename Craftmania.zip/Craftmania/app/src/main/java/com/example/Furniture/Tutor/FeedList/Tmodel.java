package com.example.Furniture.Tutor.FeedList;

public class Tmodel {

    String email,feedback;

    public Tmodel(String email, String feedback) {
        this.email = email;
        this.feedback = feedback;
    }

    public String getEmail() {
        return email;
    }

    public String getFeedback() {
        return feedback;
    }
}

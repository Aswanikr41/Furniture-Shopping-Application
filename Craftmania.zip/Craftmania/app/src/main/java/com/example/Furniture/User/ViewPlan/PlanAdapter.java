package com.example.Furniture.User.ViewPlan;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.Filter;
import android.widget.Filterable;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.example.Furniture.Config;
import com.example.Furniture.R;
import com.example.Furniture.Session;
import com.example.Furniture.User.ViewPlans;
import com.squareup.picasso.Picasso;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class PlanAdapter extends RecyclerView.Adapter<PlanAdapter.MyViewHolder>implements Filterable {
    Context mCtx;
    private List<PlanModel> dataModelArrayList;
    private List<PlanModel> dataModelArrayListFiltered;
    private LayoutInflater inflater;
    boolean counter = true;

    public PlanAdapter(Context mCtx, List<PlanModel> dataModelArrayList) {
        this.mCtx = mCtx;
        this.dataModelArrayList = dataModelArrayList;
        inflater = LayoutInflater.from(mCtx);
        this.dataModelArrayListFiltered = dataModelArrayList;
    }



    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = inflater.inflate(R.layout.list_plans, parent, false);
        MyViewHolder holder = new MyViewHolder(view);
        return holder;
    }



    @Override
    public void onBindViewHolder(@NonNull MyViewHolder holder, @SuppressLint("RecyclerView") final int position) {
        final PlanModel model = dataModelArrayListFiltered.get(position);
        holder.cname.setText(model.getCname());
        holder.cprice.setText("Price:" + model.getCprice());
        Picasso.get().load(Config.imageURL + dataModelArrayListFiltered.get(position).getImage()).into(holder.img);


        fetching(holder,position,model.getCname());





        holder.card.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                PlanModel p = dataModelArrayListFiltered.get(position);
                String id = p.getId();
                String name = p.getSellername();
                String phone = p.getSellerphone();
                String cname = p.getCname();
                String cprice = p.getCprice();
                String cdes = p.getCdescription();
                String cloc = p.getClocation();
                String im =   p.getImage();
                String stock = p.getCquantity();
                String sid = p.getSellerid();

                Intent i = new Intent(mCtx, ViewPlans.class);
                i.putExtra("id", id);
                i.putExtra("sname", name);
                i.putExtra("sphone", phone);
                i.putExtra("cname", cname);
                i.putExtra("cprice", cprice);
                i.putExtra("cdes", cdes);
                i.putExtra("cloc",cloc);
                i.putExtra("image", im);
                i.putExtra("stock", stock);
                i.putExtra("sid", sid);


                mCtx.startActivity(i);
            }
        });
        holder.button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (counter) {
                    holder.button.setBackgroundResource(R.drawable.ic_baseline_favorite_red);
                    wishlist(model.getSellername(), model.getSellerphone(), model.getImage(),
                            model.getCname(), model.getCprice(), model.getCdescription(), model.getClocation());
                }

                else {
                    unfav(model.getCname());
                    holder.button.setBackgroundResource(R.drawable.ic_baseline_favorite_white);

                }
                counter=!counter;
            }
        });

    }

    private void fetching(MyViewHolder holder, int position,String cname) {
        String userid;
        final String[] favourite = new String[1];
        String url=Config.baseURL+"wishstatus.php";
        HashMap<String, String> user = new Session(mCtx).getUserDetails();
        userid=user.get("id");
        final String[] status = new String[1];

        StringRequest s = new StringRequest(Request.Method.POST, url,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        try {
//                            Toast.makeText(mCtx, response, Toast.LENGTH_SHORT).show();

                            JSONObject c = new JSONObject(response);
                            status[0] = c.getString("status");
                            favourite[0] = c.getString("favourite");
//                            holder.display.setText(statuses[0]);

                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                        if (status[0].equals("1")) {
//                            Toast.makeText(mCtx, "aa", Toast.LENGTH_SHORT).show();

                            if(favourite[0].equals("")){
                                holder.button.setBackgroundResource(R.drawable.ic_baseline_favorite_white);
                            }
                            else if(favourite[0].equals("1")){
                                holder.button.setBackgroundResource(R.drawable.ic_baseline_favorite_red);
                            }
                            else if(favourite[0].equals("0")){
                                holder.button.setBackgroundResource(R.drawable.ic_baseline_favorite_white);
                            }
                        }
//                        else{
//                            Toast.makeText(mCtx, "error", Toast.LENGTH_SHORT).show();
//                        }

                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Toast.makeText(mCtx, error.toString(), Toast.LENGTH_SHORT).show();
                    }
                }) {
            @Override
            protected Map<String, String> getParams() {
                Map<String, String> m = new HashMap<>();
                m.put("userid", userid);
                m.put("cname",cname);

                return m;
            }
        };

        RequestQueue q = Volley.newRequestQueue(mCtx);
        q.add(s);


    }

    private void unfav(String cname) {

        final String[] status = {""};
        final String url = Config.baseURL +"deletewish.php";
        HashMap<String,String>user=new Session(mCtx).getUserDetails();
        String userid=user.get("id");
//        String fav="0";
        StringRequest s = new StringRequest(Request.Method.POST, url,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        try {
//                            Toast.makeText(mCtx, response, Toast.LENGTH_SHORT).show();
                            JSONObject c = new JSONObject(response);
                            status[0] = c.getString("StatusID");
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                        if (status[0].equals("1")) {
                            Toast.makeText(mCtx, "Removed Successfully", Toast.LENGTH_SHORT).show();
//                            c.startActivity(new Intent(c, AgriProductListActivity.class));
//                            ((Activity)c).finish();
                        }
                        else{
                            Toast.makeText(mCtx, "error", Toast.LENGTH_SHORT).show();
                        }
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Toast.makeText(mCtx, error.toString(), Toast.LENGTH_SHORT).show();
                    }
                }) {
            @Override
            protected Map<String, String> getParams() {
                Map<String, String> m = new HashMap<>();
                m.put("cname", cname);
                m.put("userid", userid);
//                m.put("favourite", fav);
                return m;
            }
        };
        RequestQueue q = Volley.newRequestQueue(mCtx);
        q.add(s);

    }

    private void wishlist(String sellername, String sellerphone, String image, String cname, String cprice, String cdescription, String clocation) {
        final String[] status = {""};
        final String[] error = {""};
        String fav = "1";
        String url= Config.baseURL +"wishlist.php";

HashMap<String,String>user=new Session(mCtx).getUserDetails();
String userid=user.get("id");
        StringRequest s = new StringRequest(Request.Method.POST, url,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        try {
                           // Toast.makeText(mCtx, response, Toast.LENGTH_SHORT).show();
                            JSONObject c = new JSONObject(response);
                            status[0] = c.getString("Status");
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                        if (status[0].equals("1")) {
                            Toast.makeText(mCtx, "added", Toast.LENGTH_SHORT).show();

                        }
                        else{
                            Toast.makeText(mCtx, "error", Toast.LENGTH_SHORT).show();
                        }
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Toast.makeText(mCtx, error.toString(), Toast.LENGTH_SHORT).show();
                    }
                }) {
            @Override
            protected Map<String, String> getParams() {
                Map<String, String> m = new HashMap<>();
                m.put("userid", userid);
                m.put("sellername", sellername);
                m.put("sellerphone", sellerphone);
                m.put("cname", cname);
                m.put("cprice", cprice);
                m.put("cdescription", cdescription);
                m.put("clocation", clocation);
                m.put("image", image);
                m.put("favourite", fav);
                return m;
            }
        };
        RequestQueue q = Volley.newRequestQueue(mCtx);
        q.add(s);
    }


    @Override
    public int getItemCount() {
        return dataModelArrayListFiltered.size();
    }

    @Override
    public Filter getFilter() {
        return new Filter() {
            @Override
            protected FilterResults performFiltering(CharSequence charSequence) {
                String charString = charSequence.toString();
                if (charString.isEmpty()) {
                    dataModelArrayListFiltered = dataModelArrayList;
                } else {
                    List<PlanModel> filteredList = new ArrayList<>();
                    for (PlanModel row : dataModelArrayList) {

                        // name match condition. this might differ depending on your requirement
                        // here we are looking for name or phone number match
                        if (row.getClocation().toLowerCase().contains(charString.toLowerCase()) ||
                                row.getCname().toLowerCase().contains(charString.toLowerCase())) {
                            filteredList.add(row);
                        }
                    }

                    dataModelArrayListFiltered = filteredList;
                }

                FilterResults filterResults = new FilterResults();
                filterResults.values = dataModelArrayListFiltered;
                return filterResults;
            }

            @Override
            protected void publishResults(CharSequence charSequence, FilterResults filterResults) {
                notifyDataSetChanged();
            }
        };
    }


    class MyViewHolder extends RecyclerView.ViewHolder{

        TextView cname,cprice,cdescription,clocation;
         ImageView img;
         Button button;
         CardView card;
        public MyViewHolder(View itemView) {
            super(itemView);
            img = itemView.findViewById(R.id.pimage);
             cname= itemView.findViewById(R.id.cname);
            cprice = itemView.findViewById(R.id.cprice);
            cdescription = itemView.findViewById(R.id.cdescription);
           // clocation = itemView.findViewById(R.id.cloc);
            card = itemView.findViewById(R.id.card);
           button=itemView.findViewById(R.id.wish);
          // location=itemView.findViewById(R.id.loc);

        }

        }

}

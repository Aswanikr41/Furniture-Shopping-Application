package com.example.Furniture.Seller;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Filter;
import android.widget.Filterable;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.example.Furniture.Config;
import com.example.Furniture.R;
import com.example.Furniture.User.ViewPlan.PlanModel;
import com.squareup.picasso.Picasso;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class newAdapter extends RecyclerView.Adapter<newAdapter.MyViewHolder>implements Filterable {
    Context mCtx;
    private List<PlanModel> dataModelArrayList;
    private List<PlanModel> dataModelArrayListFiltered;
    private LayoutInflater inflater;

    public newAdapter(Context mCtx, List<PlanModel> dataModelArrayList) {
        this.mCtx = mCtx;
        this.dataModelArrayList = dataModelArrayList;
        inflater = LayoutInflater.from(mCtx);
        this.dataModelArrayListFiltered = dataModelArrayList;
    }



    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = inflater.inflate(R.layout.myplans, parent, false);
        MyViewHolder holder = new MyViewHolder(view);
        return holder;
    }



    @Override
    public void onBindViewHolder(@NonNull MyViewHolder holder, @SuppressLint("RecyclerView") final int position) {
        final PlanModel model = dataModelArrayListFiltered.get(position);
        holder.cname.setText(model.getCname());
        holder.cprice.setText(model.getCprice());
        holder.cquantity.setText(model.getCquantity());
        Picasso.get().load(Config.imageURL + model.getImage()).into(holder.img);


        if(model.getCquantity().equals("0")){
            holder.cquantity.setText("Out of stock");
            holder.cquantity.setTextColor(Color.parseColor("#ff0000"));
        }

        holder.remove.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                removeItem(model.getCname());
            }
        });

        holder.ustock.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                PlanModel p = dataModelArrayList.get(position);
                String id = p.getId();
                String cname = p.getCname();
                String stock = p.getCquantity();
                String sid = p.getSellerid();

                Intent i = new Intent(mCtx, Updatestock.class);
                i.putExtra("id", id);
                i.putExtra("cname", cname);
                i.putExtra("stock", stock);
                i.putExtra("sid", sid);
                mCtx.startActivity(i);

            }
        });

    }

    private void removeItem(String cname) {
        final String[] status = {""};
        String id;
        final String url = Config.baseURL +"deleteplans.php";
        HashMap<String,String>user=new SellerSession(mCtx).getUserDetails();
        id=user.get("id");
        StringRequest s = new StringRequest(Request.Method.POST, url,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        try {
//                            Toast.makeText(mCtx, response, Toast.LENGTH_SHORT).show();
                            JSONObject c = new JSONObject(response);
                            status[0] = c.getString("StatusID");
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                        if (status[0].equals("1")) {
                            Toast.makeText(mCtx, "Removed Successfully", Toast.LENGTH_SHORT).show();
                            mCtx.startActivity(new Intent(mCtx, BottomActivity.class));
                            ((Activity)mCtx).finish();
                        }
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Toast.makeText(mCtx, error.toString(), Toast.LENGTH_SHORT).show();
                    }
                }) {
            @Override
            protected Map<String, String> getParams() {
                Map<String, String> m = new HashMap<>();
                m.put("sellerid", id);
                m.put("cname", cname);
                return m;
            }
        };
        RequestQueue q = Volley.newRequestQueue(mCtx);
        q.add(s);


    }


    @Override
    public int getItemCount() {
        return dataModelArrayListFiltered.size();
    }

    @Override
    public Filter getFilter() {
        return new Filter() {
            @Override
            protected FilterResults performFiltering(CharSequence charSequence) {
                String charString = charSequence.toString();
                if (charString.isEmpty()) {
                    dataModelArrayListFiltered = dataModelArrayList;
                } else {
                    List<PlanModel> filteredList = new ArrayList<>();
                    for (PlanModel row : dataModelArrayList) {

                        // name match condition. this might differ depending on your requirement
                        // here we are looking for name or phone number match
                        if (row.getCname().toLowerCase().contains(charString.toLowerCase()) ||
                                row.getCprice().toLowerCase().contains(charString.toLowerCase())) {
                            filteredList.add(row);
                        }
                    }

                    dataModelArrayListFiltered = filteredList;
                }

                FilterResults filterResults = new FilterResults();
                filterResults.values = dataModelArrayListFiltered;
                return filterResults;
            }

            @Override
            protected void publishResults(CharSequence charSequence, FilterResults filterResults) {
                notifyDataSetChanged();
            }
        };
    }


    class MyViewHolder extends RecyclerView.ViewHolder{

        TextView cname,cprice,cquantity,clocation;
        ImageView img;
        CardView card;
        TextView remove,ustock;
        public MyViewHolder(View itemView) {
            super(itemView);
            img = itemView.findViewById(R.id.pimage);
            cname= itemView.findViewById(R.id.pname);
            cprice = itemView.findViewById(R.id.price);
            cquantity = itemView.findViewById(R.id.quantity);
           ustock=itemView.findViewById(R.id.ustock);
            card = itemView.findViewById(R.id.card);
            remove=itemView.findViewById(R.id.removes);

        }

    }

}

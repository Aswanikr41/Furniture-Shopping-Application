package com.example.Furniture.Seller;

public class CustomModel {
    String id,userid,username,phone,location,qn,mb,len,wid,des,image,itemname;

    public CustomModel(String id, String userid, String username, String phone, String location, String qn, String mb,
                       String len, String wid, String des, String image,String itemname) {
        this.id = id;
        this.userid = userid;
        this.username = username;
        this.phone = phone;
        this.location = location;
        this.qn = qn;
        this.mb = mb;
        this.len = len;
        this.wid = wid;
        this.des = des;
        this.image = image;
        this.itemname = itemname;
    }

    public String getId() {
        return id;
    }

    public String getUserid() {
        return userid;
    }

    public String getUsername() {
        return username;
    }

    public String getPhone() {
        return phone;
    }

    public String getLocation() {
        return location;
    }

    public String getQn() {
        return qn;
    }

    public String getMb() {
        return mb;
    }

    public String getLen() {
        return len;
    }

    public String getWid() {
        return wid;
    }

    public String getDes() {
        return des;
    }

    public String getImage() {
        return image;
    }

    public String getItemname() {
        return itemname;
    }
}

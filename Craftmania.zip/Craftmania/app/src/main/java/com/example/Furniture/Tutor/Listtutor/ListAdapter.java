package com.example.Furniture.Tutor.Listtutor;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.Furniture.Config;
import com.example.Furniture.R;
import com.example.Furniture.Tutor.fee.Feelist;
import com.example.Furniture.User.Tutor_feedback;
import com.squareup.picasso.Picasso;

import java.util.ArrayList;

public class ListAdapter extends RecyclerView.Adapter<ListAdapter.MyViewHolder>  {
    private LayoutInflater inflater;
    private ArrayList<ModelTutor> dataModelArrayList;
    Context c;

    public ListAdapter(Context ctx, ArrayList<ModelTutor> dataModelArrayList) {
        c = ctx;
        inflater = LayoutInflater.from(ctx);
        this.dataModelArrayList = dataModelArrayList;

    }

    @NonNull
    @Override


    public ListAdapter.MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = inflater.inflate(R.layout.t_item, parent, false);
        ListAdapter.MyViewHolder holder = new ListAdapter.MyViewHolder(view);

        return holder;
    }

    @Override
    public void onBindViewHolder(@NonNull ListAdapter.MyViewHolder holder, @SuppressLint("RecyclerView") int position) {
        final ModelTutor model = dataModelArrayList.get(position);
        holder.name.setText("Name  :" + dataModelArrayList.get(position).getUsername());
        holder.email.setText("Email : "+ dataModelArrayList.get(position).getEmail());
        holder.phone.setText("Contact No : "+ dataModelArrayList.get(position).getPhone_number());
        if (!dataModelArrayList.get(position).getIdproof().equals("")) {
            Picasso.get().load(Config.imageURL + dataModelArrayList.get(position).getIdproof()).into(holder.proof);
        }


        holder.c.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ModelTutor p = dataModelArrayList.get(position);
                String id=p.getTutor_id();
                String phone=p.getPhone_number();
                String name=p.getUsername();
                Intent intent=new Intent(c,Feelist.class);
                intent.putExtra("phone",phone);
                intent.putExtra("tutor_id",id);
                intent.putExtra("name",name);
                c.startActivity(intent);
            }
        });
        holder.f.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ModelTutor p = dataModelArrayList.get(position);
                String id=p.getTutor_id();
                String name=p.getUsername();
                Intent intent=new Intent(c, Tutor_feedback.class);

                intent.putExtra("tid",id);
                intent.putExtra("tname",name);
                c.startActivity(intent);
            }
        });


    }

    @Override
    public int getItemCount() {
        return dataModelArrayList.size();
    }

    public class MyViewHolder extends RecyclerView.ViewHolder {
        TextView name,email,phone;
        ImageView proof;
        Button c,f;
        LinearLayout cardView;

        public MyViewHolder(@NonNull View itemView) {
            super(itemView);
            name=itemView.findViewById(R.id.name);
            email=itemView.findViewById(R.id.email);
            phone=itemView.findViewById(R.id.phone);
            proof=itemView.findViewById(R.id.proof);
            cardView=itemView.findViewById(R.id.cardss);
            c=itemView.findViewById(R.id.coure);
            f=itemView.findViewById(R.id.feed);


        }
    }
}

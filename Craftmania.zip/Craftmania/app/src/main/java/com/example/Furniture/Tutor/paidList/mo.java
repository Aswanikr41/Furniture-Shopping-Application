package com.example.Furniture.Tutor.paidList;

public class mo {
    String  username,userphone,status,amount,screenimg;
    public mo(String username, String userphone, String status,String amount,String screenimg) {
        this.username = username;
        this.userphone = userphone;
        this.status = status;
        this.amount = amount;
        this.screenimg = screenimg;
    }

    public String getUsername() {
        return username;
    }

    public String getUserphone() {
        return userphone;
    }

    public String getStatus() {
        return status;
    }
    public String getAmount() {
        return amount;
    }
    public String getScreenimg() {
        return screenimg;
    }
}

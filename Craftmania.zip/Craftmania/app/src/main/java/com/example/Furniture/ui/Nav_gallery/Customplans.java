package com.example.Furniture.ui.Nav_gallery;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import com.example.Furniture.Config;
import com.example.Furniture.PayActivity;
import com.example.Furniture.R;
import com.example.Furniture.Session;
import com.example.Furniture.ZoomActivity;
import com.example.Furniture.messages.LoginReg.LoginActivity;
import com.squareup.picasso.Picasso;

import org.json.JSONException;
import org.json.JSONObject;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

public class Customplans extends AppCompatActivity {
    TextView sellname, sellphone, cname, stock, cprice, cdes, clocation;
    String cnames, cprices, cdesc, cstock, sellnames, sellphones;
    String userid, id, username, email, phone, imgs, status, message, ulocation, locs;
    ImageView img;
    Button buy, wishlist, sub, cart;

    int calculate;
    int p, q;
    String sid,bdate,btime;
    String total, pr, am;
    TextView tamount;
    TextView displayInteger;
    String display;
    Button btndec, btnincr;
    int mininteger = 0;
    String url=Config.baseURL+"carts.php";
    String url1=Config.baseURL+"updateslot.php";
    String burl=Config.baseURL+"Buy.php";

    @SuppressLint("ResourceAsColor")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_customplans);

        sellname = findViewById(R.id.name);
        sellphone = findViewById(R.id.phone);
        cname = findViewById(R.id.cname);
        cprice = findViewById(R.id.cprice);
        cdes = findViewById(R.id.cdes);
        clocation = findViewById(R.id.loc);
        stock = findViewById(R.id.stock);
        img = findViewById(R.id.image);
        btndec = findViewById(R.id.btndec);
        btnincr = findViewById(R.id.btninc);
        buy = findViewById(R.id.buy);
        cart = findViewById(R.id.cart);
        tamount = findViewById(R.id.amount);
        displayInteger = findViewById(R.id.value);
        wishlist = findViewById(R.id.wish);
        sub = findViewById(R.id.sub1);


        bdate = new SimpleDateFormat("dd/MM/yyyy", Locale.getDefault()).format(new Date());
        btime = new SimpleDateFormat("HH:mm:ss", Locale.getDefault()).format(new Date());


        img.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(Customplans.this, ZoomActivity.class);
                i.putExtra("image", imgs);
                startActivity(i);
            }
        });


        HashMap<String, String> user = new Session(Customplans.this).getUserDetails();
        userid = user.get("id");
        username = user.get("username");
        email = user.get("email_id");
        phone = user.get("mobilenumber");
        ulocation = user.get("location");
        //Toast.makeText(this, userid + username + phone + email, Toast.LENGTH_SHORT).show();

        Intent intent = getIntent();
        id = intent.getStringExtra("id");
        sellnames = intent.getStringExtra("sname");
        sellphones = intent.getStringExtra("sphone");
        cnames = intent.getStringExtra("cname");
        cprices = intent.getStringExtra("cprice");
        cdesc = intent.getStringExtra("cdes");
        locs = intent.getStringExtra("cloc");
        imgs = intent.getStringExtra("image");
        cstock = intent.getStringExtra("cqauntity");
        sid = intent.getStringExtra("sid");
//        Toast.makeText(getApplicationContext(), cstock, Toast.LENGTH_SHORT).show();

        String imageurl = Config.imageURL + imgs;
        Picasso.get().load(imageurl).into(img);

        sellname.setText(sellnames + id);
        sellphone.setText(sellphones);
        cname.setText(cnames);
        cprice.setText(cprices);
        cdes.setText(cdesc);
        stock.setText(cstock);
        clocation.setText(locs);

        int num=Integer.parseInt(cstock);
        if(num<=5){
            stock.setText("Hurry only" +" "+cstock+" "+"left!");
            stock.setTextColor(Color.parseColor("#1662C6"));
        }
        if(cstock.equals("0")){
            stock.setText("Out of stock");
            stock.setTextColor(Color.parseColor("#D50000"));
        }


        btnincr.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mininteger = mininteger + 1;
                display(mininteger);

//                int d=Integer.parseInt( display );
//                int s=Integer.parseInt( quantity );
//
//                if (d>s)
//                {
//                    Toast.makeText( ViewProductActivity.this, "Given Stock is Unavailable", Toast.LENGTH_SHORT ).show();
//               amount.setVisibility(View.GONE);
//                }


            }
        });

        btndec.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (mininteger > 0) {
                    mininteger = mininteger - 1;
                    display(mininteger);
                    decrement(mininteger);
                }
            }
        });

        cart.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (displayInteger.getText().toString().equals("0"))
                    Toast.makeText(Customplans.this, "Please Select Quantity", Toast.LENGTH_SHORT).show();
                else {
                    cart();
                }
            }
        });

        buy.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //int d1=Integer.parseInt( display);
                if (displayInteger.getText().toString().equals("0"))
                    Toast.makeText(Customplans.this, "Please Select Quantity", Toast.LENGTH_SHORT).show();
                else {
                    buys();
                }

            }
        });

    }

    private void decrement(int number) {
        displayInteger = findViewById(R.id.value);
        displayInteger.setText("" + number);

    }

    private void buys() {

        int d = Integer.parseInt(display);
        int s = Integer.parseInt(cstock);

        if (d > s) {
            Toast.makeText(this, "Given Stock is Unavailable", Toast.LENGTH_SHORT).show();
        } else {

            StringRequest stringRequest = new StringRequest(Request.Method.POST, burl,
                    new Response.Listener<String>() {
                        @Override
                        public void onResponse(String response) {
                            try {
                                JSONObject c = new JSONObject(response);
                                status = c.getString("status");
                                message = c.getString("message");
                            } catch (JSONException e) {
                                e.printStackTrace();
                            }

                            if (status.equals("1")) {
                                Toast.makeText(Customplans.this, "Order booked", Toast.LENGTH_SHORT).show();
                                updateSlot();
                            } else {
                                Toast.makeText(Customplans.this, "Network error", Toast.LENGTH_SHORT).show();
                            }
                        }
                    },
                    new Response.ErrorListener() {
                        @Override
                        public void onErrorResponse(VolleyError error) {
                            Toast.makeText(Customplans.this, error.toString(), Toast.LENGTH_SHORT).show();
                        }
                    }) {
                @Override
                protected Map<String, String> getParams() {
                    Map<String, String> m = new HashMap<>();
                    m.put("product_name", cnames);
                    m.put("product_price", cprices);
                    m.put("product_quantity", display);
                    m.put("product_image", imgs);
                    m.put("username", username);
                    m.put("userid", userid);
                    m.put("userphone",phone);
                    m.put("sellerid",sid);
                    m.put("sellername", sellnames);
                    m.put("sellerphone", sellphones);
                    m.put("gtotal",am);
                    m.put("bdate", bdate);
                    m.put("btime", btime);
                    m.put("ulocation", ulocation);
                    return m;
                }
            };
            Volley.newRequestQueue(this).add(stringRequest);
        }
    }




    private void cart() {
        int d = Integer.parseInt(display);
        int s = Integer.parseInt(cstock);

        if (d > s) {
            Toast.makeText(this, "Given Stock is Unavailable", Toast.LENGTH_SHORT).show();
        } else {
            StringRequest stringRequest = new StringRequest(Request.Method.POST, url,
                    new Response.Listener<String>() {
                        @Override
                        public void onResponse(String response) {
                            try {
                                JSONObject c = new JSONObject(response);
                                status = c.getString("status");
                            } catch (JSONException e) {
                                e.printStackTrace();
                            }
                            if ("1".equals(status)) {
                                Toast.makeText(Customplans.this, "Added to cart", Toast.LENGTH_SHORT).show();
//                                updateSlot();
                            } else {
                                Toast.makeText(Customplans.this, "Network error", Toast.LENGTH_SHORT).show();
                            }
                        }
                    },
                    new Response.ErrorListener() {
                        @Override
                        public void onErrorResponse(VolleyError error) {
                            Toast.makeText(Customplans.this, error.toString(), Toast.LENGTH_SHORT).show();
                        }
                    }) {
                @Override
                protected Map<String, String> getParams() {
                    Map<String, String> m = new HashMap<>();
                    m.put("product_id", id);
                    m.put("product_name", cnames);
                    m.put("product_price", cprices);
                    m.put("product_quantity", display);
                    m.put("product_image", imgs);
                    m.put("username", username);
                    m.put("userid", userid);
                    m.put("total", am);
                    return m;
                }
            };
            Volley.newRequestQueue(this).add(stringRequest);
        }

    }

    private void updateSlot() {
        int s=Integer.parseInt( display );
        int updateslot=Integer.parseInt(cstock)-s;

        StringRequest stringRequest = new StringRequest(Request.Method.POST, url1,
                new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                try {
//                    Toast.makeText(getApplicationContext(), response, Toast.LENGTH_SHORT).show();
                    JSONObject c = new JSONObject(response);
                    status = c.getString("status");
                    message = c.getString("message");
                } catch (JSONException e) {
                    e.printStackTrace();
                }
                if (status.equals("1")) {
//                    Toast.makeText(Customplans.this, "message", Toast.LENGTH_SHORT).show();
                          Intent i=new Intent(getApplicationContext(), PayActivity.class);
                          i.putExtra("amount",am);
                          startActivity(i);
                } else {
                    Toast.makeText(Customplans.this, "error", Toast.LENGTH_SHORT).show();
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Toast.makeText(Customplans.this, error.toString(), Toast.LENGTH_SHORT).show();
            }
        }){
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                Map<String,String> map = new HashMap<>();
                map.put("id",id);
                map.put("product_quantity", String.valueOf(updateslot));
                return map;
            }
        };
        RequestQueue requestQueue = Volley.newRequestQueue(this);
        requestQueue.add(stringRequest);

    }


    private void display(int number) {

        displayInteger.setText("" + number);
        pr = cprice.getText().toString();
        total = displayInteger.getText().toString();
        p = Integer.parseInt(pr);
        q = Integer.parseInt(total);
        calculate = p * q;
        tamount.setText(String.valueOf(calculate));
        display = displayInteger.getText().toString();
        am = tamount.getText().toString();


    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.chat_menu, menu);

        return super.onCreateOptionsMenu(menu);
    }
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        //handle menu item clicks
        int id = item.getItemId();

        if (id == R.id.chat_menu) {
            Intent intent = new Intent(Customplans.this, LoginActivity.class);
            startActivity(intent);
            //do your function here
        }  return super.onOptionsItemSelected(item);
    }





    private void call() {
        Intent intent = new Intent(Intent.ACTION_DIAL);
        intent.setData(Uri.parse("tel:" + sellphones));
        startActivity(intent);


    }


}
package com.example.Furniture.Seller.BuyedPlans;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import com.example.Furniture.Config;
import com.example.Furniture.R;
import com.example.Furniture.Seller.BottomActivity;
import com.example.Furniture.Seller.SellerSession;
import com.squareup.picasso.Picasso;

import org.json.JSONException;
import org.json.JSONObject;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

public class Viewbuyeditems extends AppCompatActivity {
    TextView sellname, sellphone, cname, stock, cprice, cdes, clocation,prevsatus;
    String cnames, cprices, amount, cstock, sellnames, sellphones;
    String userid, id, username, email, phone, imgs, status, message, links, locs,modes1,scimg;
    ImageView img,screenimg;
    Button sub;
    Spinner spinner;
    String[]stat={"Select status","Order confirmed","Order packed","Order dispatched","Out for delivery","delivered"};
    String sid,bdate,btime,spindata,userids,usernames,userphns,prevsts;
    TextView tamount,modes;
    String url1=Config.baseURL+"updateStatus.php";

    @SuppressLint("ResourceAsColor")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_viewbuyeditems);
        sellname = findViewById(R.id.name);
        sellphone = findViewById(R.id.phone);
        cname = findViewById(R.id.cname);
        cprice = findViewById(R.id.cprice);
        clocation = findViewById(R.id.loc);
        stock = findViewById(R.id.stock);
        img = findViewById(R.id.image);
        tamount = findViewById(R.id.tamounts);
        sub = findViewById(R.id.update);
        spinner = findViewById(R.id.sts);
        prevsatus = findViewById(R.id.previous);
        screenimg = findViewById(R.id.screenimage);
        modes = findViewById(R.id.mode);


        bdate = new SimpleDateFormat("dd/MM/yyyy", Locale.getDefault()).format(new Date());
        btime = new SimpleDateFormat("HH:mm:ss", Locale.getDefault()).format(new Date());



        HashMap<String, String> user = new SellerSession(Viewbuyeditems.this).getUserDetails();
        userid = user.get("id");
        username = user.get("Username");
        phone = user.get("Mobile_number");
        //Toast.makeText(this, userid + username + phone + email, Toast.LENGTH_SHORT).show();

        Intent intent = getIntent();
        id = intent.getStringExtra("id");
        userids = intent.getStringExtra("userid");
        usernames = intent.getStringExtra("username");
        userphns = intent.getStringExtra("userphn");

        cnames = intent.getStringExtra("cname");
        cprices = intent.getStringExtra("cprice");
        imgs = intent.getStringExtra("image");
        cstock = intent.getStringExtra("stock");
        sid = intent.getStringExtra("sid");
        locs = intent.getStringExtra("cloc");
        amount = intent.getStringExtra("gtotal");
        prevsts = intent.getStringExtra("status");
        modes1 = intent.getStringExtra("mode");
        scimg = intent.getStringExtra("screenshot");

        Toast.makeText(this, modes1, Toast.LENGTH_SHORT).show();

        if(prevsts.equals("")){
            prevsatus.setVisibility(View.GONE);
        }

        String imageurl = Config.imageURL + imgs;
        Picasso.get().load(imageurl).into(img);

        String imageurl1 = Config.imageURL + scimg;
        Picasso.get().load(imageurl1).into(screenimg);

        sellname.setText(usernames + id);
        sellphone.setText(userphns);
        cname.setText(cnames);
        cprice.setText(cprices);
        stock.setText(cstock);
        clocation.setText(locs);
        tamount.setText("Total amount : " + amount);
        prevsatus.setText("Previous Status : " + prevsts);
        modes.setText("Payment Mode : " + modes1);


        ArrayAdapter<String> adapter=new ArrayAdapter(getApplicationContext(),R.layout.support_simple_spinner_dropdown_item,stat);
        spinner.setAdapter(adapter);

        sub.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                adds();
            }
        });

    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.chat_menu, menu);

        return super.onCreateOptionsMenu(menu);
    }
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        //handle menu item clicks
        int id = item.getItemId();

        if (id == R.id.chat_menu) {
            watsapp();
        }
        return super.onOptionsItemSelected(item);
    }

    private void watsapp() {
        Uri mUri = Uri.parse("smsto:" + userphns);
        Intent mIntent = new Intent(Intent.ACTION_SENDTO, mUri);
        mIntent.setPackage("com.whatsapp");
        mIntent.putExtra("sms_body", "The text goes here");
        mIntent.putExtra("chat", true);
        startActivity(Intent.createChooser(mIntent, ""));
    }


    private void adds() {
        spindata=spinner.getSelectedItem().toString();

        StringRequest stringRequest = new StringRequest(Request.Method.POST, url1,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        try {
//                            Toast.makeText(getApplicationContext(), response, Toast.LENGTH_SHORT).show();
                            JSONObject c = new JSONObject(response);
                            status = c.getString("status");
                            message = c.getString("message");
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                        if (status.equals("1")) {
                            Toast.makeText(Viewbuyeditems.this, "Status updated", Toast.LENGTH_SHORT).show();
                            startActivity(new Intent(getApplicationContext(), BottomActivity.class));
                        } else {
                            Toast.makeText(Viewbuyeditems.this, "error", Toast.LENGTH_SHORT).show();
                        }
                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Toast.makeText(Viewbuyeditems.this, error.toString(), Toast.LENGTH_SHORT).show();
            }
        }){
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                Map<String,String> map = new HashMap<>();
                map.put("userid",userids);
                map.put("product_name",cnames);
                map.put("status",spindata);
                return map;
            }
        };
        RequestQueue requestQueue = Volley.newRequestQueue(this);
        requestQueue.add(stringRequest);

    }


}
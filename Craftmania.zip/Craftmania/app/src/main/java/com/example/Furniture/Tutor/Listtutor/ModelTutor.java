package com.example.Furniture.Tutor.Listtutor;

public class ModelTutor {
    String tutor_id,username,email,phone_number,idproof;

    public ModelTutor(String tutor_id, String username, String email, String phone_number, String idproof) {
        this.tutor_id = tutor_id;
        this.username = username;
        this.email = email;
        this.phone_number = phone_number;
        this.idproof = idproof;
    }

    public String getTutor_id() {
        return tutor_id;
    }

    public String getUsername() {
        return username;
    }

    public String getEmail() {
        return email;
    }

    public String getPhone_number() {
        return phone_number;
    }

    public String getIdproof() {
        return idproof;
    }
}

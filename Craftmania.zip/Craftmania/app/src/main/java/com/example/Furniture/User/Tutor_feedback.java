package com.example.Furniture.User;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.example.Furniture.Config;
import com.example.Furniture.R;
import com.example.Furniture.Session;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;
import java.util.regex.Pattern;

public class Tutor_feedback extends AppCompatActivity {

    EditText ema,feedbackk,tutorname;
    Button sub;

    String email,feedback;
    String url= Config.baseURL+"feedback.php";
    String status,error;
    String tid,tnames;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tutor_feedback);
        ema = findViewById(R.id.email);
        feedbackk =findViewById(R.id.feed2);
        sub =findViewById(R.id.sub1);
        tutorname =findViewById(R.id.tname);




        Intent i=getIntent();
        tid=i.getStringExtra("tid");
        tnames=i.getStringExtra("tname");
        tutorname.setText(tnames);


        HashMap<String,String> user=new Session(getApplicationContext()).getUserDetails();
        email=user.get("email_id");
        ema.setText(email);


        sub.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                feedfn();
            }
        });


    }




    private void feedfn() {

        email = ema.getText().toString();
        feedback = feedbackk.getText().toString();

        if (TextUtils.isEmpty(email)) {
            ema.setError("Please enter email");
            ema.requestFocus();
            return;
        } else if (!isEmailValid(email)) {
            ema.setError("Invalid email id");
            ema.requestFocus();
            return;
        }

        else if (TextUtils.isEmpty(feedback)) {
            feedbackk.setError("Please Enter the feedback");
            feedbackk.requestFocus();
            return;
        }


        StringRequest request = new StringRequest(Request.Method.POST, url,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {

                        try {
//                            Toast.makeText(getApplicationContext(), "aa", Toast.LENGTH_SHORT).show();
                            JSONObject j = new JSONObject(response);
                            status = j.getString("Status");
                            error = j.getString("Error");

                        } catch (JSONException e) {
                            e.printStackTrace();
                        }

                        if("0".equals(status)) {
                            Toast.makeText(getApplicationContext(), error, Toast.LENGTH_SHORT).show();
                        } else {
                            Toast.makeText(getApplicationContext(), " successfull", Toast.LENGTH_SHORT).show();
                            Intent intent = new Intent(getApplicationContext(), BottomActivity2.class);
                            startActivity(intent);
                        }
                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Toast.makeText(getApplicationContext(), error.toString(), Toast.LENGTH_SHORT).show();
            }
        }) {
            @Override
            protected Map<String, String> getParams() {
                Map<String, String> map = new HashMap<>();
                map.put("email", email);
                map.put("feedback", feedback);
                map.put("tid", tid);
                map.put("tname", tnames);
                return map;
            }
        };

        RequestQueue q = Volley.newRequestQueue(getApplicationContext());
        q.add(request);

    }


    public static boolean isEmailValid(String email) {
        String emailRegex = "^[a-zA-Z0-9_+&*-]+(?:\\."+
                "[a-zA-Z0-9_+&*-]+)*@" +
                "(?:[a-zA-Z0-9-]+\\.)+[a-z" +
                "A-Z]{2,7}$";

        Pattern pat = Pattern.compile(emailRegex);
        return pat.matcher(email).matches();



    }

}

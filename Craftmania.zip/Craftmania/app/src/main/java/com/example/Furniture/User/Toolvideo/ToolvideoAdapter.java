package com.example.Furniture.User.Toolvideo;

import android.content.Context;
import android.text.method.LinkMovementMethod;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;


import com.example.Furniture.R;

import java.util.ArrayList;

public class ToolvideoAdapter extends RecyclerView.Adapter<ToolvideoAdapter.MyViewHolder> {
    private LayoutInflater inflater;
    private ArrayList<VideoModel> dataModelArrayList;
    Context c;

    public ToolvideoAdapter(Context ctx, ArrayList<VideoModel> dataModelArrayList) {
        c = ctx;
        inflater = LayoutInflater.from(ctx);
        this.dataModelArrayList = dataModelArrayList;
    }

    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = inflater.inflate(R.layout.tool_card, parent, false);
        MyViewHolder holder = new MyViewHolder(view);
        return holder;
    }

    @Override
    public void onBindViewHolder(@NonNull MyViewHolder holder, int position) {
        final VideoModel product = dataModelArrayList.get(position);

        holder.tvtool.setText("Description: " + product.getPlan());
        holder.tvurl.setText("Video URL: " + product.getUrl());
    }

    @Override
    public int getItemCount() {
        return dataModelArrayList.size();
    }



    class MyViewHolder extends RecyclerView.ViewHolder {
        TextView tvtool;
                TextView tvurl;

        public MyViewHolder(@NonNull View itemView) {
            super(itemView);
            tvtool = itemView.findViewById(R.id.plan);
            tvurl = itemView.findViewById(R.id.url);
           // tvurl.setText(Html.fromHtml(html));
            tvurl.setMovementMethod(LinkMovementMethod.getInstance());
        }
    }

}
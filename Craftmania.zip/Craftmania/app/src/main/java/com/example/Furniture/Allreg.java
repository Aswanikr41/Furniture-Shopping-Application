package com.example.Furniture;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Spinner;

import com.example.Furniture.Seller.SellersignupActivity;
import com.example.Furniture.Tutor.TutorReg;
import com.example.Furniture.User.Registraction;

public class Allreg extends AppCompatActivity {
    Button SubmittReg;
    Spinner spinner;
    String[] iam = {"Click here to choose", "User"};
    String spin;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_allreg);
        spinner = findViewById(R.id.spiniam);
        SubmittReg = findViewById(R.id.submitReg);

        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, R.layout.support_simple_spinner_dropdown_item, iam);
        spinner.setAdapter((adapter));


        SubmittReg.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                blood();
            }
        });
    }

    private void blood() {
        spin=spinner.getSelectedItem().toString();
        if(spin.equals("User")){
            Intent i=new Intent(getApplicationContext(), Registraction.class);
            i.putExtra("User",spin);
            startActivity(i);
        }
//           startActivity(new Intent(getApplicationContext(),BloodregActivity.class));
//       }
        if(spin.equals("Seller")) {
            Intent i=new Intent(getApplicationContext(), SellersignupActivity.class);
            i.putExtra("Seller",spin);
            startActivity(i);
        }

        if(spin.equals("Tutor")) {
            Intent i=new Intent(getApplicationContext(), TutorReg.class);
            i.putExtra("Tutor",spin);
            startActivity(i);
        }
    }




}
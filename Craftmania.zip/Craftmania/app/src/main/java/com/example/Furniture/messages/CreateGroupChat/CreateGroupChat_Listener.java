package com.example.Furniture.messages.CreateGroupChat;

public interface CreateGroupChat_Listener {
    void onGroupChatAction(Boolean isSelected);
}

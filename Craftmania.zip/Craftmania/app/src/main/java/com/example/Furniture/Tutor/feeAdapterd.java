package com.example.Furniture.Tutor;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.example.Furniture.Config;
import com.example.Furniture.R;
import com.example.Furniture.Tutor.fee.feeModel;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class feeAdapterd extends RecyclerView.Adapter<feeAdapterd.MyViewHolder> {
    private LayoutInflater inflater;
    private ArrayList<feeModel> dataModelArrayList;
    Context c;


    public feeAdapterd(Context ctx, ArrayList<feeModel> dataModelArrayList) {
        c = ctx;
        inflater = LayoutInflater.from(ctx);
        this.dataModelArrayList = dataModelArrayList;

    }

    @NonNull
    @Override


    public feeAdapterd.MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = inflater.inflate(R.layout.myfee, parent, false);
        feeAdapterd.MyViewHolder holder = new feeAdapterd.MyViewHolder(view);
        return holder;
    }

    @Override
    public void onBindViewHolder(@NonNull MyViewHolder holder, @SuppressLint("RecyclerView") int position) {
        final feeModel model = dataModelArrayList.get(position);
        holder.cname.setText("CourseName : " + dataModelArrayList.get(position).getCoursename());
        holder.cduration.setText("Duration: " + dataModelArrayList.get(position).getDuration());
        holder.camount.setText("Fees :" + dataModelArrayList.get(position).getFee());
        holder.remove.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                removeItem(model.getCoursename());
            }
        });
    }


    private void removeItem(String cname) {
        final String[] status = {""};
        String id;
        final String url = Config.baseURL +"deletefees.php";
        HashMap<String,String>user=new TutorSession(c).getUserDetails();
        id=user.get("id");
        StringRequest s = new StringRequest(Request.Method.POST, url,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        try {
//                            Toast.makeText(mCtx, response, Toast.LENGTH_SHORT).show();
                            JSONObject c = new JSONObject(response);
                            status[0] = c.getString("StatusID");
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                        if (status[0].equals("1")) {
                            Toast.makeText(c, "Removed Successfully", Toast.LENGTH_SHORT).show();
                            c.startActivity(new Intent(c, TutorActivity.class));
                            ((Activity)c).finish();
                        }
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Toast.makeText(c, error.toString(), Toast.LENGTH_SHORT).show();
                    }
                }) {
            @Override
            protected Map<String, String> getParams() {
                Map<String, String> m = new HashMap<>();
                m.put("tutorid", id);
                m.put("coursename", cname);
                return m;
            }
        };
        RequestQueue q = Volley.newRequestQueue(c);
        q.add(s);


    }

      @Override
    public int getItemCount() {
        return dataModelArrayList.size();
    }

    public class MyViewHolder extends RecyclerView.ViewHolder {
        TextView cname, camount, cduration,tname,tnumber;
        LinearLayout card;
        Button remove;
//        TextView display;


        public MyViewHolder(@NonNull View itemView) {
            super(itemView);
            cname = itemView.findViewById(R.id.cname);
            camount = itemView.findViewById(R.id.camount);
            cduration = itemView.findViewById(R.id.cduration);
            card = itemView.findViewById(R.id.card);
            remove = itemView.findViewById(R.id.remove);

        }
    }


}

package com.example.Furniture.User.Toolvideo;

public class VideoModel {
    String plan,url;

    public VideoModel(String plan, String url) {
        this.plan = plan;
        this.url = url;
    }

    public String getPlan() {
        return plan;
    }

    public String getUrl() {
        return url;
    }
}

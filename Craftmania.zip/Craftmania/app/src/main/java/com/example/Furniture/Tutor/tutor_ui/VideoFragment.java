package com.example.Furniture.Tutor.tutor_ui;

import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.example.Furniture.Config;
import com.example.Furniture.R;
import com.example.Furniture.Tutor.TutorSession;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

public class VideoFragment extends Fragment {

    EditText desc,urls;
    Button btn;
    String url= Config.baseURL+"video.php";
    String statusid,error;
    String name,type,tutor_id;


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view= inflater.inflate(R.layout.fragment_video, container, false);
        desc=view.findViewById(R.id.plan);
        urls=view.findViewById(R.id.url);
        btn=view.findViewById(R.id.btnUpload);

        HashMap<String,String>user=new TutorSession(getActivity()).getUserDetails();
        tutor_id=user.get("id");
        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                upload();
            }
        });
        return  view;
    }

    private void upload() {

        name = desc.getText().toString();
        type = urls.getText().toString();

        if (TextUtils.isEmpty(name)) {
            desc.setError("enter plan ideas");
            desc.requestFocus();
            return;
        }

        if (TextUtils.isEmpty(type)) {
            urls.setError("Copy video url");
            urls.requestFocus();
            return;
        }

        StringRequest s=new StringRequest(Request.Method.POST, url,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        try {

                            JSONObject j=new JSONObject(response);
                            statusid=j.getString("status");
                            error=j.getString("message");
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                        if ("0".equals(statusid))
                        {
                            Toast.makeText(getActivity(), error, Toast.LENGTH_SHORT).show();
                        }
                        else
                        {
                            Toast.makeText(getActivity(), "Upload Successfully", Toast.LENGTH_SHORT).show();
//                            Intent i = new Intent(getContext(), UploadLocationActivity.class);
//                            i.putExtra("username", username);
//                            startActivity(i);
//                            finish();
                        }

                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        //progress.setVisibility(View.GONE);
                        Toast.makeText(getActivity(), error.toString(), Toast.LENGTH_SHORT).show();

                    }
                }){
            @Override
            protected Map<String, String> getParams()  {
                Map<String,String> m=new HashMap<>();
                m.put("plan_idea",name);
                m.put("url",type);
                m.put("tutor_id",tutor_id);
                return m;

            }
        };
        RequestQueue r= Volley.newRequestQueue(getActivity());
        r.add(s);


    }
}
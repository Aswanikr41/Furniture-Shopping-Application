package com.example.Furniture.ui.slideshow;

public class CartModel {

    private String id,product_id,product_name,product_price,product_quantity,product_image,username,userid,total;

    public CartModel(String id, String product_id, String product_name, String product_price, String product_quantity, String product_image, String username, String userid, String total) {
        this.id = id;
        this.product_id = product_id;
        this.product_name = product_name;
        this.product_price = product_price;
        this.product_quantity = product_quantity;
        this.product_image = product_image;
        this.username = username;
        this.userid = userid;
        this.total = total;
    }

    public String getId() {
        return id;
    }

    public String getProduct_id() {
        return product_id;
    }

    public String getProduct_name() {
        return product_name;
    }

    public String getProduct_price() {
        return product_price;
    }

    public String getProduct_quantity() {
        return product_quantity;
    }

    public String getProduct_image() {
        return product_image;
    }

    public String getUsername() {
        return username;
    }

    public String getUserid() {
        return userid;
    }

    public String getTotal() {
        return total;
    }
}

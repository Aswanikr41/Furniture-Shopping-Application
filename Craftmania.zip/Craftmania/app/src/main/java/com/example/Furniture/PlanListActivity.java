package com.example.Furniture;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.RecyclerView;

import com.example.Furniture.Seller.AddPlans;
import com.example.Furniture.User.ViewPlan.PlanAdapter;
import com.example.Furniture.User.ViewPlan.PlanModel;
import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.util.ArrayList;

public class PlanListActivity extends AppCompatActivity {
    private String url = Config.baseURL + "list_plan.php";
    private ArrayList<PlanModel> dataModelArrayList;
    private PlanAdapter rvAdapter;
    private RecyclerView recyclerView;
    FloatingActionButton floatingActionButton;
    String budget;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_plan_list);
        recyclerView = findViewById(R.id.recycler);
        floatingActionButton=findViewById(R.id.fb);
        Intent i=getIntent();
        budget=i.getStringExtra("spin");
        Toast.makeText(this, budget, Toast.LENGTH_SHORT).show();

        //fetchingJSON();
        floatingActionButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i=new Intent(PlanListActivity.this, AddPlans.class);
                startActivity(i);
            }
        });
    }

//    private void fetchingJSON() {
//        StringRequest stringRequest = new StringRequest(Request.Method.POST, url,
//                new Response.Listener<String>() {
//                    @Override
//                    public void onResponse(String response) {
//
//                        try {
//                            Toast.makeText(getApplicationContext(), response, Toast.LENGTH_SHORT).show();
//
//                            dataModelArrayList = new ArrayList<>();
//                            JSONArray array = new JSONArray(response);
//
//                            for (int i = 0; i < array.length(); i++) {
//
//                                JSONObject dataobj = array.getJSONObject(i);
//
//
//                                dataModelArrayList.add(new PlanModel(
//                                        dataobj.getString("id"),
//                                        dataobj.getString("Floor"),
//                                        dataobj.getString("Image"),
//                                        dataobj.getString("Squarefeet"),
//                                        dataobj.getString("Budget"),
//                                        dataobj.getString("Description"),
//                                        dataobj.getString("pdf"),
//                                        dataobj.getString("sellername"),
//                                        dataobj.getString("sellerphone"),
//                                        dataobj.getString("status")
//                                ));
//                            }
//                            setupRecycler();
//
//                        } catch (JSONException e) {
//                            e.printStackTrace();
//                        }
//                    }
//                },
//                new Response.ErrorListener() {
//                    @Override
//                    public void onErrorResponse(VolleyError error) {
//                        // p.setVisibility(View.GONE);
//                        Toast.makeText(getApplicationContext(), error.toString(), Toast.LENGTH_SHORT).show();
//                    }
//                }) {
//            @Override
//            protected Map<String, String> getParams() {
//                Map<String, String> params = new HashMap<>();
//                params.put("Budget",budget);
//                return params;
//            }
//        };
//        RequestQueue requestQueue = Volley.newRequestQueue(getApplicationContext());
//        requestQueue.add(stringRequest);
//    }
//
//    private void setupRecycler() {
//        rvAdapter = new PlanAdapter(PlanListActivity.this, dataModelArrayList);
//        recyclerView.setHasFixedSize(true);
//        recyclerView.setAdapter(rvAdapter);
//        recyclerView.setLayoutManager(new LinearLayoutManager(PlanListActivity.this, RecyclerView.VERTICAL, false));
//    }
    }

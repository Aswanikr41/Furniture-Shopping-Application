package com.example.Furniture.ui.slideshow;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.Filter;
import android.widget.Filterable;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.example.Furniture.Config;
import com.example.Furniture.NavigationActivity;
import com.example.Furniture.R;
import com.squareup.picasso.Picasso;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class CartAdapter extends RecyclerView.Adapter<CartAdapter.MyViewHolder> implements Filterable {

    private LayoutInflater inflater;
    private ArrayList<CartModel> dataModelArrayList;
    private Context c;

    public CartAdapter(Context ctx, ArrayList<CartModel> dataModelArrayList){
        c = ctx;
        inflater = LayoutInflater.from(c);
        this.dataModelArrayList = dataModelArrayList;
    }


    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = inflater.inflate(R.layout.list_cart, parent, false);
        MyViewHolder holder = new MyViewHolder(view);
        return holder;
    }


    @Override
    public void onBindViewHolder(@NonNull MyViewHolder holder, @SuppressLint("RecyclerView") final int position) {
        final CartModel product = dataModelArrayList.get(position);
        holder.prname.setText(dataModelArrayList.get(position).getProduct_name());
        holder.pprice.setText("Price: "+dataModelArrayList.get(position).getProduct_price());
        holder.pquantity.setText("Quantity: "+dataModelArrayList.get(position).getProduct_quantity());
        holder.total.setText("Total amount: "+dataModelArrayList.get(position).getTotal());
        if (!dataModelArrayList.get(position).getProduct_image().equals("")) {
            Picasso.get().load(Config.imageURL + dataModelArrayList.get(position).getProduct_image()).into(holder.imageView);
        }

        holder.delete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                removeItem(product.getId(),product.getUserid());
            }
        });

    }

    private void removeItem(String pid,String userid) {
        final String[] status = {""};
        final String url = Config.baseURL +"deletecarts.php";
        //Toast.makeText(c, pid+userid, Toast.LENGTH_SHORT).show();

        StringRequest s = new StringRequest(Request.Method.POST, url,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        try {
       //                     Toast.makeText(c, response, Toast.LENGTH_SHORT).show();
                            JSONObject c = new JSONObject(response);
                            status[0] = c.getString("StatusID");
                       } catch (JSONException e) {
                            e.printStackTrace();
                        }
                       if (status[0].equals("1")) {
                            Toast.makeText(c, "Removed Successfully", Toast.LENGTH_SHORT).show();
                            c.startActivity(new Intent(c, NavigationActivity.class));
                            ((Activity)c).finish();
                       }
                    }
               },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        //Toast.makeText(c, error.toString(), Toast.LENGTH_SHORT).show();
                    }
                }) {
            @Override
            protected Map<String, String> getParams() {
                Map<String, String> m = new HashMap<>();
                m.put("product_id", pid);
                m.put("userid", userid);
                return m;
            }
        };
        RequestQueue q = Volley.newRequestQueue(c);
        q.add(s);


    }


    @Override
    public int getItemCount() {
        return dataModelArrayList.size();
    }

    @Override
    public Filter getFilter() {
        return null;
    }


    class MyViewHolder extends RecyclerView.ViewHolder{

        TextView prname,pprice,pquantity,total;
        ImageView imageView;
        CardView rootLayout;
        Button delete;

        public MyViewHolder(View itemView) {
            super(itemView);
            imageView=itemView.findViewById(R.id.ivImage);
            prname = itemView.findViewById(R.id.pname);
            pprice = itemView.findViewById(R.id.price);
            pquantity = itemView.findViewById(R.id.quantity);
            delete = itemView.findViewById(R.id.cancel);
            total = itemView.findViewById(R.id.total);
            rootLayout = itemView.findViewById(R.id.rootLayout);
        }
    }

}

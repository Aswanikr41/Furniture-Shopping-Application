package com.example.Furniture;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.example.Furniture.Seller.BottomActivity;
import com.example.Furniture.Seller.SellerSession;
import com.example.Furniture.Tutor.TutorActivity;
import com.example.Furniture.Tutor.TutorSession;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

public class OptionActivity extends AppCompatActivity {
    Spinner spinner;
    EditText user,pass;
    Button btnlogin;
    TextView textreg;
    String[] iam={"Click here to choose","User","Admin"};
    String usern,passw,spin,status,error,Username,Mobile_number,Email,location,id;
    String users=Config.baseURL+"login.php";
    String seller=Config.baseURL+"sellerlog.php";
    String tutor=Config.baseURL+"tutorlogin.php";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_option);
        spinner=findViewById(R.id.spins);
        ArrayAdapter<String> adapter = new ArrayAdapter<>( this,R.layout.support_simple_spinner_dropdown_item,iam);
        spinner.setAdapter((adapter));

        user = findViewById(R.id.username);
        pass = findViewById(R.id.password);
        btnlogin=findViewById(R.id.signbutton);
        textreg=findViewById(R.id.account);

        textreg.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(getApplicationContext(), Allreg.class));
            }
        });


        btnlogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                login();
            }
        });

    }

    private void login() {
        usern=user.getText().toString();
        passw=pass.getText().toString();
        spin=spinner.getSelectedItem().toString();


        if (TextUtils.isEmpty(usern)) {
            user.setError("Required field");
            user.requestFocus();
            return;
        }
        if (TextUtils.isEmpty(passw)) {
            pass.setError("Required field");
            pass.requestFocus();
            return;
        }
//        if (passw.isEmpty() || passw.length() < 6) {
//            pass.setError("Password cannot be less than 6 characters!");
//        }
        if(spin.equals("User")){
            userlogin();
        }
        if(spin.equals("Admin")){
            sellerlogin();
        }
//        if(spin.equals("Tutor")){
//            tutorLogin();
//        }

    }

    private void sellerlogin() {
        StringRequest request = new StringRequest(Request.Method.POST,seller,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
//                        loader.setVisibility(View.INVISIBLE);

                        try {
//                    Toast.makeText(OptionActivity.this, response, Toast.LENGTH_SHORT).show();
                                JSONObject jsnb = new JSONObject(response);
                                status = jsnb.getString("status");
                                error = jsnb.getString("message");
                                id = jsnb.getString("id");
                                Username = jsnb.getString("Username");
                                Mobile_number = jsnb.getString("Mobile_number");
                                Email = jsnb.getString("Email");
                                location = jsnb.getString("location");

                            } catch (JSONException e) {
                                e.printStackTrace();
                            }

                            if ("0".equals(status)) {
                                Toast.makeText(OptionActivity.this, error, Toast.LENGTH_SHORT).show();
                            } else {
                                Toast.makeText(OptionActivity.this, "Login Successfull", Toast.LENGTH_SHORT).show();
                                new SellerSession(OptionActivity.this).createLoginSession(id, Username, Mobile_number, Email, location);
                                Intent i = new Intent(OptionActivity.this, BottomActivity.class);
                                startActivity(i);
                                finish();
                            }
//
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
//                        loader.setVisibility(View.INVISIBLE);
                        Toast.makeText(OptionActivity.this, error.toString(), Toast.LENGTH_SHORT).show();
                    }
                }) {
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                Map<String, String> params = new HashMap<>();
                params.put("Username", usern);
                params.put("Password", passw);
                params.put("type",spin);
                return params;
            }
        };

        RequestQueue queue = Volley.newRequestQueue(this);
        queue.add(request);

    }

    private void tutorLogin() {
        StringRequest request = new StringRequest(Request.Method.POST,tutor,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
//                        loader.setVisibility(View.INVISIBLE);

                        try {
//                           Toast.makeText(OptionActivity.this,response , Toast.LENGTH_SHORT).show();
                            //JSON Parsing
                            JSONObject jsnb = new JSONObject(response);
                            status = jsnb.getString("status");
                            error = jsnb.getString("message");
                            id = jsnb.getString("id");
                            Username = jsnb.getString("username");
                            Email = jsnb.getString("email");
                            Mobile_number = jsnb.getString("phone_number");
                            location = jsnb.getString("college");


                        } catch (JSONException e) {
                            e.printStackTrace();
                        }

                        if ("0".equals(status)) {
                            Toast.makeText(OptionActivity.this, error, Toast.LENGTH_SHORT).show();
                        } else {
                            Toast.makeText(OptionActivity.this, "Login Successfull", Toast.LENGTH_SHORT).show();
                            new TutorSession(OptionActivity.this).createLoginSession(id,Username,Email,Mobile_number,location);
                            Intent i = new Intent(OptionActivity.this, TutorActivity.class);
                            startActivity(i);
                            finish();
                        }
                    }

                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
//                        loader.setVisibility(View.INVISIBLE);
                        Toast.makeText(OptionActivity.this, error.toString(), Toast.LENGTH_SHORT).show();
                    }
                }) {
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                Map<String, String> params = new HashMap<>();
                params.put("username", usern);
                params.put("password", passw);
                params.put("type",spin);
                return params;
            }
        };

        RequestQueue queue = Volley.newRequestQueue(this);
        queue.add(request);

    }

    private void userlogin() {

        StringRequest request = new StringRequest(Request.Method.POST,users,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
//                        loader.setVisibility(View.INVISIBLE);

                        try {
//                            Toast.makeText(OptionActivity.this,response , Toast.LENGTH_SHORT).show();
                            //JSON Parsing
                            JSONObject jsnb = new JSONObject(response);
                            status = jsnb.getString("status");
                            error = jsnb.getString("message");
                            id=jsnb.getString("id");
                            Username=jsnb.getString("username");
                            Mobile_number=jsnb.getString("Mobile_number");
                            Email=jsnb.getString("Email_id");
                            location=jsnb.getString("location");

                        } catch (JSONException e) {
                            e.printStackTrace();
                        }

                        if ("0".equals(status)) {
                            Toast.makeText(OptionActivity.this, error, Toast.LENGTH_SHORT).show();
                        } else {
                            Toast.makeText(OptionActivity.this, "Login Successfull", Toast.LENGTH_SHORT).show();
                            Intent i = new Intent(OptionActivity.this, NavigationActivity.class);
                            new Session(OptionActivity.this).createLoginSession(id,Username,Mobile_number,Email,location);
                            startActivity(i);
                            finish();
                        }
                    }

                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
//                        loader.setVisibility(View.INVISIBLE);
                        Toast.makeText(OptionActivity.this, error.toString(), Toast.LENGTH_SHORT).show();
                    }
                }) {
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                Map<String, String> params = new HashMap<>();
                params.put("username",usern);
                params.put("password", passw);
                params.put("type",spin);
                return params;
            }
        };

        RequestQueue queue = Volley.newRequestQueue(this);
        queue.add(request);

    }
}
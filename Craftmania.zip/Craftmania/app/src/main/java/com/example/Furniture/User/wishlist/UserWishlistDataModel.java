package com.example.Furniture.User.wishlist;

public class UserWishlistDataModel {

    String userid,sellername, sellerphone,cname,cprice,cdescription,clocation,image;

    public UserWishlistDataModel(String userid, String sellername, String sellerphone, String cname, String cprice, String cdescription, String clocation, String image) {
        this.userid = userid;
        this.sellername = sellername;
        this.sellerphone = sellerphone;
        this.cname = cname;
        this.cprice = cprice;
        this.cdescription = cdescription;
        this.clocation = clocation;
        this.image = image;
    }

    public String getUserid() {
        return userid;
    }

    public String getSellername() {
        return sellername;
    }

    public String getSellerphone() {
        return sellerphone;
    }

    public String getCname() {
        return cname;
    }

    public String getCprice() {
        return cprice;
    }

    public String getCdescription() {
        return cdescription;
    }

    public String getClocation() {
        return clocation;
    }

    public String getImage() {
        return image;
    }
}
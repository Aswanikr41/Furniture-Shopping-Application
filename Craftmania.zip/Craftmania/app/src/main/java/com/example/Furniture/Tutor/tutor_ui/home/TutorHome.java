package com.example.Furniture.Tutor.tutor_ui.home;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import androidx.fragment.app.Fragment;

import com.example.Furniture.Config;
import com.example.Furniture.R;
import com.example.Furniture.Seller.EditProfile;
import com.example.Furniture.Tutor.TutorSession;

import java.util.HashMap;


public class TutorHome extends Fragment {
    TextView fusername, femail, fphonenumber, fpassword;
    Button feditprofile, fhelp, fabout, flogout;
    String id,username, email_id, mobile_number, password;
    String url = Config.baseURL+"editprofile.php";
    String status, error;


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View root= inflater.inflate(R.layout.tutor_home, container, false);
        fusername = root.findViewById(R.id.user);
        femail = root.findViewById(R.id.email);
        fphonenumber = root.findViewById(R.id.phone);
        feditprofile = root.findViewById(R.id.btnEdit);

        HashMap<String, String> m = new TutorSession(getActivity()).getUserDetails();
        username = m.get("username");
        mobile_number = m.get("phone_number");
        email_id = m.get("email");

        fusername.setText(username);
        femail.setText(email_id);
        fphonenumber.setText(mobile_number);
        feditprofile.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i=new Intent(getActivity(), EditProfile.class);
                startActivity(i);
            }
        });
        return root;
    }

//    private void editpr() {
//        StringRequest str = new StringRequest(Request.Method.POST, url, new Response.Listener<String>() {
//            @Override
//            public void onResponse(String response) {
//
//                Toast.makeText(getActivity(), response, Toast.LENGTH_SHORT).show();
//
//                try {
//                    JSONObject jsnb = new JSONObject(response);
//                    status = jsnb.getString("status");
//                    error = jsnb.getString("message");
//
//                } catch (JSONException e) {
//                    e.printStackTrace();
//                }
//                if ("0".equals(status)) {
//                    Toast.makeText(getActivity(), error, Toast.LENGTH_SHORT).show();
//                } else {
//                    Toast.makeText(getActivity(), "Registration successfull", Toast.LENGTH_SHORT).show();
//                    getActivity().finish();
//
//                }
//            }
//        }, new Response.ErrorListener() {
//            @Override
//            public void onErrorResponse(VolleyError error) {
//
//                Toast.makeText(getActivity(), error.toString(), Toast.LENGTH_SHORT).show();
//
//            }
//        }) {
//
//            @Override
//            protected Map<String, String> getParams() {
//                Map<String, String> params = new HashMap<>();
//                params.put("id",id);
//                params.put("Username", username);
//                params.put("Mobile_number", mobile_number);
//                params.put("Email_id", email_id);
//                return params;
//            }
//        };
//        RequestQueue rq = Volley.newRequestQueue(getActivity());
//        rq.add(str);
//
//    }
}

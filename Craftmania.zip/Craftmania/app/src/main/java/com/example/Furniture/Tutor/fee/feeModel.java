package com.example.Furniture.Tutor.fee;

public class feeModel {
    String id,coursename,fee,description,duration,tutorid;

    public feeModel(String id, String coursename, String fee, String description, String duration, String tutorid) {
        this.id = id;
        this.coursename = coursename;
        this.fee = fee;
        this.description = description;
        this.duration = duration;
        this.tutorid = tutorid;
    }

    public String getId() {
        return id;
    }

    public String getCoursename() {
        return coursename;
    }

    public String getFee() {
        return fee;
    }

    public String getDescription() {
        return description;
    }

    public String getDuration() {
        return duration;
    }

    public String getTutorid() {
        return tutorid;
    }
}

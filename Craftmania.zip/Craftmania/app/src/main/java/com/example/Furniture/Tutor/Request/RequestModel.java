package com.example.Furniture.Tutor.Request;

public class RequestModel {
    String username,userphone,usercourse,userfee,status;

    public RequestModel(String username, String userphone, String usercourse, String userfee, String status) {
        this.username = username;
        this.userphone = userphone;
        this.usercourse = usercourse;
        this.userfee = userfee;
        this.status = status;
    }

    public String getUsername() {
        return username;
    }

    public String getUserphone() {
        return userphone;
    }

    public String getUsercourse() {
        return usercourse;
    }

    public String getUserfee() {
        return userfee;
    }

    public String getStatus() {
        return status;
    }
}

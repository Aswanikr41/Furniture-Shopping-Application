package com.example.Furniture.Seller.BuyedPlans;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;

import com.example.Furniture.Config;
import com.example.Furniture.R;
import com.squareup.picasso.Picasso;

import java.util.ArrayList;

public class BAdapter extends RecyclerView.Adapter<BAdapter.MyViewHolder> {

    private LayoutInflater inflater;
    private ArrayList<BModel> dataModelArrayList;
    private Context c;

    public BAdapter(Context ctx, ArrayList<BModel> dataModelArrayList){
        c = ctx;
        inflater = LayoutInflater.from(c);
        this.dataModelArrayList = dataModelArrayList;
    }


    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = inflater.inflate(R.layout.myplan, parent, false);
        MyViewHolder holder = new MyViewHolder(view);
        return holder;
    }


    @Override
    public void onBindViewHolder(@NonNull MyViewHolder holder, @SuppressLint("RecyclerView") final int position) {
        final BModel product = dataModelArrayList.get(position);
        holder.prname.setText(dataModelArrayList.get(position).getProduct_name());
        holder.pprice.setText("Price: "+dataModelArrayList.get(position).getProduct_price());
        holder.pquantity.setText("Quantity: "+dataModelArrayList.get(position).getProduct_quantity());
        holder.username.setText("Username: "+dataModelArrayList.get(position).getUsername());

        Picasso.get().load(Config.imageURL + product.getProduct_image()).into(holder.imageView);



        holder.rootLayout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                BModel p = dataModelArrayList.get(position);
                String id = p.getId();
                String name = p.getSellername();
                String phone = p.getSellerphone();
                String cname = p.getProduct_name();
                String cprice = p.getProduct_price();
                String im =   p.getProduct_image();
                String stock = p.getProduct_quantity();
                String sid = p.getSellerid();
                String uloc = p.getUlocation();
                String gtotal = p.getGtotal();
                String userid = p.getUserid();
                String username = p.getUsername();
                String userphn = p.getUserphone();
                String status = p.getStatus();

                Intent i = new Intent(c, Viewbuyeditems.class);
                i.putExtra("id", id);
                i.putExtra("sname", name);
                i.putExtra("sphone", phone);
                i.putExtra("cname", cname);
                i.putExtra("cprice", cprice);
                i.putExtra("cloc",uloc);
                i.putExtra("image", im);
                i.putExtra("stock", stock);
                i.putExtra("sid", sid);
                i.putExtra("gtotal", gtotal);
                i.putExtra("userid", userid);
                i.putExtra("username", username);
                i.putExtra("userphn", userphn);
                i.putExtra("status", status);
                i.putExtra("mode", p.getMode());
                i.putExtra("screenshot", p.getScreenshot());


                c.startActivity(i);
            }

        });

    }



    @Override
    public int getItemCount() {
        return dataModelArrayList.size();
    }




    class MyViewHolder extends RecyclerView.ViewHolder{

        TextView prname,pprice,pquantity,username;
        ImageView imageView;
        CardView rootLayout;
        Button delete;

        public MyViewHolder(View itemView) {
            super(itemView);
            imageView=itemView.findViewById(R.id.ivImage);
            prname = itemView.findViewById(R.id.pname);
            pprice = itemView.findViewById(R.id.price);
            pquantity = itemView.findViewById(R.id.quantity);
            delete = itemView.findViewById(R.id.cancel);
            username = itemView.findViewById(R.id.username);
            rootLayout = itemView.findViewById(R.id.rootLayout);
        }
    }

}

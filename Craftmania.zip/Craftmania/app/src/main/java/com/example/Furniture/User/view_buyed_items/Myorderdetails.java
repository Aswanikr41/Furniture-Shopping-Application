package com.example.Furniture.User.view_buyed_items;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RatingBar;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import com.example.Furniture.Config;
import com.example.Furniture.R;
import com.example.Furniture.Session;
import com.squareup.picasso.Picasso;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

public class Myorderdetails extends AppCompatActivity {
    TextView sellname, sellphone, cname, stock, cprice, cdes, clocation;
    String cnames, cprices, amount, cstock;
    String userid, id, username, email, phone, imgs, status, message, links, locs;
    ImageView img;
    Button sub;
    Spinner spinner;
    String sid,userids,usernames,userphns;
    TextView tamount;
    LinearLayout linearLayout;
    TextView oview,oconform,opacked,odispatched,oout,odeliver;
    RatingBar ratingBar;
    EditText editfeed;
    String editfeeds,ratingvalue;
    float ratings;
    String urlrating=Config.baseURL+"updateReview.php";

    @SuppressLint("ResourceAsColor")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_myorderdetails);
        sellname = findViewById(R.id.name);
        sellphone = findViewById(R.id.phone);
        cname = findViewById(R.id.cname);
        cprice = findViewById(R.id.cprice);
        clocation = findViewById(R.id.loc);
        stock = findViewById(R.id.stock);
        img = findViewById(R.id.image);
        tamount = findViewById(R.id.tamounts);
        sub = findViewById(R.id.btnsub);
        oconform=findViewById( R.id.oconform );
        opacked=findViewById( R.id.opacked );
        odispatched=findViewById( R.id.odispatched );
        odeliver=findViewById( R.id.odeliver);
        oout=findViewById( R.id.out);
        editfeed=findViewById( R.id.feed);
        linearLayout=findViewById( R.id.rating);
        ratingBar=findViewById( R.id.raingbar);


//
//        bdate = new SimpleDateFormat("dd/MM/yyyy", Locale.getDefault()).format(new Date());
//        btime = new SimpleDateFormat("HH:mm:ss", Locale.getDefault()).format(new Date());
//


        HashMap<String, String> user = new Session(Myorderdetails.this).getUserDetails();
        userid = user.get("id");
        username = user.get("username");
        phone = user.get("mobilenumber");
        //Toast.makeText(this, userid + username + phone + email, Toast.LENGTH_SHORT).show();

        Intent intent = getIntent();
        id = intent.getStringExtra("id");
        userids = intent.getStringExtra("userid");
        usernames = intent.getStringExtra("username");
        userphns = intent.getStringExtra("userphn");

        cnames = intent.getStringExtra("cname");
        cprices = intent.getStringExtra("cprice");
        imgs = intent.getStringExtra("image");
        cstock = intent.getStringExtra("stock");
        sid = intent.getStringExtra("sid");
        locs = intent.getStringExtra("cloc");
        amount = intent.getStringExtra("gtotal");
        status = intent.getStringExtra("status");
        Toast.makeText(getApplicationContext(), status, Toast.LENGTH_SHORT).show();


        String imageurl = Config.imageURL + imgs;
        Picasso.get().load(imageurl).into(img);

        sellname.setText(usernames + id);
        sellphone.setText(userphns);
        cname.setText(cnames);
        cprice.setText(cprices);
        stock.setText(cstock);
        clocation.setText(locs);
        tamount.setText("Total amount : " + amount);



        if(status.equals("Order confirmed")){

            oconform.setTextColor(Color.parseColor("#ff0000"));

        }
        if(status.equals( "Order packed" )){

            opacked.setTextColor(Color.parseColor("#ff0000"));

        }
        if(status.equals( "Order dispatched" )){

            odispatched.setTextColor(Color.parseColor("#ff0000"));

        }

        if(status.equals( "Out for delivery" )){

            oout.setTextColor(Color.parseColor("#ff0000"));


        }
        if(status.equals( "delivered" )){

            odeliver.setTextColor(Color.parseColor("#12D81A"));
            linearLayout.setVisibility(View.VISIBLE);


        }
        sub.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                rates();
            }
        });




    }

    private void rates() {
    ratings=ratingBar.getRating();

    editfeeds=editfeed.getText().toString();


        StringRequest stringRequest = new StringRequest(Request.Method.POST, urlrating,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        try {
//                            Toast.makeText(getApplicationContext(), response, Toast.LENGTH_SHORT).show();
                            JSONObject c = new JSONObject(response);
                            status = c.getString("status");
                            message = c.getString("message");
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                        if (status.equals("1")) {
                            Toast.makeText(Myorderdetails.this, "Status updated", Toast.LENGTH_SHORT).show();

                        } else {
                            Toast.makeText(Myorderdetails.this, "error", Toast.LENGTH_SHORT).show();
                        }
                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Toast.makeText(Myorderdetails.this, error.toString(), Toast.LENGTH_SHORT).show();
            }
        }){
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                Map<String,String> map = new HashMap<>();
                map.put("userid",userids);
                map.put("product_name",cnames);
                map.put("feedback",editfeeds);
                map.put("ratingvalue", String.valueOf(ratings));
                return map;
            }
        };
        RequestQueue requestQueue = Volley.newRequestQueue(this);
        requestQueue.add(stringRequest);

    }

    }
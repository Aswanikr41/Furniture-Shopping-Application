package com.example.Furniture.Seller.FeedbackList;

public class fbModel {
    String product_name,product_image,userid,username,feedback,ratingvalue;

    public fbModel(String product_name, String product_image, String userid, String username, String feedback, String ratingvalue) {
        this.product_name = product_name;
        this.product_image = product_image;
        this.userid = userid;
        this.username = username;
        this.feedback = feedback;
        this.ratingvalue = ratingvalue;
    }

    public String getProduct_name() {
        return product_name;
    }

    public String getProduct_image() {
        return product_image;
    }

    public String getUserid() {
        return userid;
    }

    public String getUsername() {
        return username;
    }

    public String getFeedback() {
        return feedback;
    }

    public String getRatingvalue() {
        return ratingvalue;
    }
}

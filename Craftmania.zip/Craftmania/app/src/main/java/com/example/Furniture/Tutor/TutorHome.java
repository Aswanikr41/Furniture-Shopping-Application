package com.example.Furniture.Tutor;

import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

import com.example.Furniture.R;
import com.example.Furniture.Seller.Add_video;
import com.example.Furniture.User.UserCall;

public class TutorHome extends AppCompatActivity {
CardView livecard,recordcard;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tutor_home);
        livecard=findViewById(R.id.live);
        recordcard=findViewById(R.id.record);
        livecard.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(getApplicationContext(), UserCall.class));

            }
        });
        recordcard.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(getApplicationContext(), Add_video.class));

            }
        });
    }
}
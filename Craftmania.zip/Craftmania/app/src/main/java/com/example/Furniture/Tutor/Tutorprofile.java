package com.example.Furniture.Tutor;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import com.example.Furniture.Config;
import com.example.Furniture.R;
import com.example.Furniture.Seller.EditProfile;

import java.util.HashMap;

public class Tutorprofile extends AppCompatActivity {
    TextView fusername, femail, fphonenumber, fpassword;
    Button feditprofile, fhelp, fabout, flogout;
    String id,username, email_id, mobile_number, password;
    String url = Config.baseURL+"editprofile.php";
    String status, error;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.tutor_home);
        fusername =findViewById(R.id.user);
        femail =findViewById(R.id.email);
        fphonenumber =findViewById(R.id.phone);
        feditprofile =findViewById(R.id.btnEdit);

        HashMap<String, String> m = new TutorSession(getApplicationContext()).getUserDetails();
        username = m.get("username");
        mobile_number = m.get("phone_number");
        email_id = m.get("email");

        fusername.setText(username);
        femail.setText(email_id);
        fphonenumber.setText(mobile_number);
        feditprofile.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i=new Intent(getApplicationContext(), EditProfile.class);
                startActivity(i);
            }
        });

    }
}

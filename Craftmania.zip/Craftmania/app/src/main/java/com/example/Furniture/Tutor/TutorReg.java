package com.example.Furniture.Tutor;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.provider.OpenableColumns;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.DefaultRetryPolicy;
import com.android.volley.NetworkResponse;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.Volley;
import com.example.Furniture.Config;
import com.example.Furniture.OptionActivity;
import com.example.Furniture.R;
import com.example.Furniture.VolleyMultipartRequest;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.util.HashMap;
import java.util.Map;

public class TutorReg extends AppCompatActivity {
    EditText UserName,MobileNumber,Emailid,PassWord,college,qualification;
    Button register;
    String url= Config.baseURL+"tutorreg.php";
    String status,error;
    String user,email,pass,phone,coll,quali;
    private RequestQueue rQueue;
    private static ProgressDialog mProgressDialog;
    String type;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tutor_reg);
        UserName=findViewById(R.id.userreg);
        MobileNumber=findViewById(R.id.phonereg);
        Emailid=findViewById(R.id.emailreg);
        PassWord=findViewById(R.id.passreg);
        college=findViewById(R.id.college);
        register=findViewById(R.id.buttonreg);
        qualification=findViewById(R.id.quali);
        Intent intent=getIntent();
        type=intent.getStringExtra("Tutor");
        register.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) { register(); }
        });
    }
    private void register(){

        user=UserName.getText().toString();
        phone=MobileNumber.getText().toString();
        email=Emailid.getText().toString();
        pass=PassWord.getText().toString();
        coll=college.getText().toString();
        quali=qualification.getText().toString();

        if (pass.isEmpty() || pass.length() < 6) {
            PassWord.setError("Password cannot be less than 6 characters!");
        }

        if (TextUtils.isEmpty(user)){
            UserName.setError("please enter usename");
            UserName.requestFocus();
            return;
        }
        else if(TextUtils.isEmpty(phone)){
            MobileNumber.setError("please type your mobile number");
            MobileNumber.requestFocus();
            return;
        }
        else if (TextUtils.isEmpty(email)){
            Emailid.setError("please enter your email id");
            Emailid.requestFocus();
            return;
        }
        else if (TextUtils.isEmpty(pass)){
            PassWord.setError("please type your password");
            PassWord.requestFocus();
            return;
        }
        else if (TextUtils.isEmpty(coll)){
            college.setError("please type your college name");
            college.requestFocus();
            return;
        }
        else if (TextUtils.isEmpty(quali)) {
            qualification.setError("please type your qualification");
            qualification.requestFocus();
            return;
        }
        // Intent to pick an image or file to upload
        Intent intent = new Intent();
        intent.setAction(Intent.ACTION_GET_CONTENT);
        intent.setType("image/*");
//        intent.setType("video/mp4");
//        intent.setType("application/pdf");
        startActivityForResult(intent, 1);
    }


    @SuppressLint("Range")
    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (resultCode == RESULT_OK) {
            // Get the Uri of the selected file
            Uri uri = data.getData();
            String uriString = uri.toString();
            File myFile = new File(uriString);
            String path = myFile.getAbsolutePath();
            String displayName = null;

            if (uriString.startsWith("content://")) {
                Cursor cursor = null;
                try {
                    cursor = TutorReg.this.getContentResolver().query(uri, null, null, null, null);
                    if (cursor != null && cursor.moveToFirst()) {
                        displayName = cursor.getString(cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME));
                        Log.d("nameeeee>>>>  ",displayName);

                        uploadPDF(displayName,uri);
                    }
                } finally {
                    cursor.close();
                }
            } else if (uriString.startsWith("file://")) {
                displayName = myFile.getName();
                Log.d("nameeeee>>>>  ",displayName);
            }
        }

        super.onActivityResult(requestCode, resultCode, data);

    }

    public void uploadPDF(final String pdfname, Uri pdffile){

        InputStream iStream = null;
        try {

            iStream =TutorReg.this. getContentResolver().openInputStream(pdffile);
            final byte[] inputData = getBytes(iStream);

            showSimpleProgressDialog(TutorReg.this, null, "Uploading image", false);

            VolleyMultipartRequest volleyMultipartRequest = new VolleyMultipartRequest(Request.Method.POST,url,
                    new Response.Listener<NetworkResponse>() {
                        @Override
                        public void onResponse(NetworkResponse response) {
                             Toast.makeText(getApplicationContext(), response.toString(), Toast.LENGTH_SHORT).show();
                            removeSimpleProgressDialog();
//                            Toast.makeText(TutorReg.this, response.toString(), Toast.LENGTH_SHORT).show();
//                            Log.d("ressssssoo",new String(response.data));
                            rQueue.getCache().clear();
                            try {

                                JSONObject jsonObject = new JSONObject(new String(response.data));

                                jsonObject.toString().replace("\\\\","");

                                status = jsonObject.getString("status");
                                error = jsonObject.getString("message");

                                if (status.equals("1")) {
                                    Toast.makeText(TutorReg.this,"File upload successfully", Toast.LENGTH_SHORT).show();
                                    Intent i=new Intent(getApplicationContext(), OptionActivity.class);
                                    startActivity(i);
                                }
                                else {
                                    Toast.makeText(TutorReg.this, error, Toast.LENGTH_SHORT).show();
                                }
                            } catch (JSONException e) {
                                e.printStackTrace();
                            }
                        }
                    },
                    new Response.ErrorListener() {
                        @Override
                        public void onErrorResponse(VolleyError error) {
                            removeSimpleProgressDialog();
                            Toast.makeText(TutorReg.this, error.toString(), Toast.LENGTH_LONG).show();
                        }
                    }) {

                /*
                 * If you want to add more parameters with the image
                 * you can do it here
                 * here we have only one parameter with the image
                 * which is tags
                 * */
                @Override
                protected Map<String, String> getParams() throws AuthFailureError {
                    Map<String, String> params = new HashMap<>();
                    //add string parameters
                    params.put("username",user);
                    params.put("email",email);
                    params.put("password",pass);
                    params.put("phone_number",phone);
                    params.put("college",coll);
                    params.put("qualification",quali);
                    params.put("type",type);
                    return params;
                }

                /*
                 *pass files using below method
                 * */
                @Override
                protected Map<String, DataPart> getByteData() {
                    Map<String, DataPart> params = new HashMap<>();

                    params.put("filename", new DataPart(pdfname ,inputData));
                    return params;
                }
            };


            volleyMultipartRequest.setRetryPolicy(new DefaultRetryPolicy(
                    0,
                    DefaultRetryPolicy.DEFAULT_MAX_RETRIES,
                    DefaultRetryPolicy.DEFAULT_BACKOFF_MULT));
            rQueue = Volley.newRequestQueue(TutorReg.this);
            rQueue.add(volleyMultipartRequest);



        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }


    }

    public byte[] getBytes(InputStream inputStream) throws IOException {
        ByteArrayOutputStream byteBuffer = new ByteArrayOutputStream();
        int bufferSize = 1024;
        byte[] buffer = new byte[bufferSize];

        int len = 0;
        while ((len = inputStream.read(buffer)) != -1) {
            byteBuffer.write(buffer, 0, len);
        }
        return byteBuffer.toByteArray();
    }


    public static void removeSimpleProgressDialog() {
        try {
            if (mProgressDialog != null) {
                if (mProgressDialog.isShowing()) {
                    mProgressDialog.dismiss();
                    mProgressDialog = null;
                }
            }
        } catch (IllegalArgumentException ie) {
            Log.e("Log", "inside catch IllegalArgumentException");
            ie.printStackTrace();
        } catch (RuntimeException re) {
            Log.e("Log", "inside catch RuntimeException");
            re.printStackTrace();
        } catch (Exception e) {
            Log.e("Log", "Inside catch Exception");
            e.printStackTrace();
        }

    }

    public static void showSimpleProgressDialog(Context context, String title,
                                                String msg, boolean isCancelable) {
        try {
            if (mProgressDialog == null) {
                mProgressDialog = ProgressDialog.show(context, title, msg);
                mProgressDialog.setCancelable(isCancelable);
            }
            if (!mProgressDialog.isShowing()) {
                mProgressDialog.show();
            }
        } catch (IllegalArgumentException ie) {
            ie.printStackTrace();
        } catch (RuntimeException re) {
            re.printStackTrace();
        } catch (Exception e) {
            e.printStackTrace();
        }


}
}
package com.example.Furniture;

public interface Config {
    String baseURL="http://192.168.225.99/livehome/";
    String imageURL="http://192.168.225.99/livehome/upload/";

}

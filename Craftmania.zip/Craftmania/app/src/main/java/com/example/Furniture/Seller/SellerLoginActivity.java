package com.example.Furniture.Seller;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.example.Furniture.Config;
import com.example.Furniture.R;


import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

public class SellerLoginActivity extends AppCompatActivity {
    EditText username, pword;
    TextView create;
    Button login;
    String status, error;
    String url= Config.baseURL+"sellerlog.php";
    String Username,Mobile_number,Email,id,location;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_seller_login);
        username = findViewById(R.id.username);
        pword = findViewById(R.id.password);
        login = findViewById(R.id.button);
        create = findViewById(R.id.account);
        login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                register();
            }
        });
        create.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent j = new Intent(SellerLoginActivity.this, SellersignupActivity.class);
                startActivity(j);
                finish();
            }
        });
    }

    private void register() {
        String user, pass;
        user = username.getText().toString();
        pass =  pword.getText().toString();
        if (TextUtils.isEmpty(user)) {
            username.setError("please enter the username");
            username.requestFocus();
            return;
        } else if (TextUtils.isEmpty(pass)) {
            pword.setError("please enter password");
            pword.requestFocus();
            return;
        }
        StringRequest str = new StringRequest(Request.Method.POST, url, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {

                try {
//                    Toast.makeText(SellerLoginActivity.this, response, Toast.LENGTH_SHORT).show();
                    JSONObject jsnb = new JSONObject(response);
                    status = jsnb.getString("status");
                    error = jsnb.getString("message");
                    id = jsnb.getString("id");
                    Username = jsnb.getString("Username");
                    Mobile_number = jsnb.getString("Mobile_number");
                    Email = jsnb.getString("Email");
                    location = jsnb.getString("location");

                } catch (JSONException e) {
                    e.printStackTrace();
                }

                if ("0".equals(status)) {
                    Toast.makeText(SellerLoginActivity.this, error, Toast.LENGTH_SHORT).show();
                } else {
                    Toast.makeText(SellerLoginActivity.this, "Login Successfull", Toast.LENGTH_SHORT).show();
                    new SellerSession(SellerLoginActivity.this).createLoginSession(id,Username,Mobile_number,Email,location);
                    Intent i = new Intent(SellerLoginActivity.this, BottomActivity.class);
                    startActivity(i);
//                    finish();
                }
            }

        },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Toast.makeText(SellerLoginActivity.this, error.toString(), Toast.LENGTH_SHORT).show();
                    }
                }) {
            @Override
            protected Map<String, String> getParams()  {
                Map<String, String> params = new HashMap<>();
                params.put("Username", user);
                params.put("Password", pass);
                return params;
            }
        };
        RequestQueue rq= Volley.newRequestQueue(this);
        rq.add(str);
    }
}

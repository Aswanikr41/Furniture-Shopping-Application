package com.example.Furniture.User.ViewPlan;

public class PlanModel {
String id,cname,cprice,cdescription,clocation,image,sellername,sellerphone,sellerid,cquantity,favourite;


    public PlanModel(String id, String cname, String cprice, String cdescription, String clocation, String image, String sellername,
                     String sellerphone, String sellerid,String cquantity,String favourite) {
        this.id = id;
        this.cname = cname;
        this.cprice = cprice;
        this.cdescription = cdescription;
        this.clocation = clocation;
        this.image = image;
        this.sellername = sellername;
        this.sellerphone = sellerphone;
        this.sellerid = sellerid;
        this.cquantity = cquantity;
        this.favourite = favourite;
    }

    public String getId() {
        return id;
    }

    public String getCname() {
        return cname;
    }

    public String getCprice() {
        return cprice;
    }

    public String getCdescription() {
        return cdescription;
    }

    public String getClocation() {
        return clocation;
    }

    public String getImage() {
        return image;
    }

    public String getSellername() {
        return sellername;
    }

    public String getSellerphone() {
        return sellerphone;
    }

    public String getSellerid() {
        return sellerid;
    }
    public String getCquantity() {
        return cquantity;
    }

    public String getFavourite() {
        return favourite;
    }
}
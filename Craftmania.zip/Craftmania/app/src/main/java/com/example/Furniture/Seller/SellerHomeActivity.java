package com.example.Furniture.Seller;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

import com.example.Furniture.R;



public class SellerHomeActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    setContentView(R.layout.activity_seller_home);
    }
}
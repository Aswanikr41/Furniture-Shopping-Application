package com.example.Furniture.Seller;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.example.Furniture.Config;
import com.example.Furniture.R;


import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

public class EditProfile extends AppCompatActivity {
EditText u,e,ph,location;
String id,username,email,phone,loc;
Button btn;
String status,error;
String url= Config.baseURL+"SellerEditP.php";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit_profile);
        u=findViewById(R.id.etUsername);
        e=findViewById(R.id.etEmail);
        ph=findViewById(R.id.etPhone);
        location=findViewById(R.id.Location);
        btn=findViewById(R.id.btnEdit);

        HashMap<String, String> m = new SellerSession(this).getUserDetails();
        id = m.get("id");
        username = m.get("Username");
        email = m.get("Email");
        phone = m.get("Mobile_number");
        loc = m.get("location");

//        if (!TextUtils.isEmpty(image)) {
//            Picasso.get().load(image).into(iv);
//        }

        u.setText(username);
        e.setText(email);
        ph.setText(phone);
        location.setText(loc);


        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                edit();
            }
        });
    }

    private void edit() {
        StringRequest s = new StringRequest(Request.Method.POST, url,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        Toast.makeText(EditProfile.this, response, Toast.LENGTH_SHORT).show();

                        try {
                             JSONObject c = new JSONObject(response);
                            status = c.getString("status");
                            error = c.getString("message");

                            if (status.equals("1")) {
                                Toast.makeText(EditProfile.this, "Changes saved successfully", Toast.LENGTH_SHORT).show();
                                finish();
                            }
                            else {
                                Toast.makeText(EditProfile.this, error, Toast.LENGTH_LONG).show();
                            }

                        } catch (JSONException e) {
                            e.printStackTrace();
                        }

                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Toast.makeText(EditProfile.this, error.toString(), Toast.LENGTH_LONG).show();
                    }
                }) {
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                Map<String, String> m = new HashMap<>();
                m.put("id", id);
                m.put("Username", username);
                m.put("Email", email);
                m.put("Mobile_number", phone);
                m.put("location", loc);
                return m;
            }
        };
        RequestQueue q = Volley.newRequestQueue(this);
        q.add(s);
    }
    }

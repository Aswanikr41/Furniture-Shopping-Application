package com.example.Furniture.ui.home;
import android.app.SearchManager;
import android.content.Context;
import android.content.Intent;
import android.graphics.drawable.AnimationDrawable;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.widget.SearchView;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.example.Furniture.Config;
import com.example.Furniture.R;
import com.example.Furniture.User.ViewPlan.PlanAdapter;
import com.example.Furniture.User.ViewPlan.PlanModel;
import com.example.Furniture.ui.Southlist.list_south;
import com.google.android.material.floatingactionbutton.FloatingActionButton;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import de.hdodenhof.circleimageview.CircleImageView;

public class Navhome extends Fragment {
    ImageView imgSaladDiseas;
    RecyclerView recyclerView;
    private ArrayList<PlanModel> dataModelArrayList;
    private PlanAdapter rvAdapter;
    private SearchView searchView = null;
    private SearchView.OnQueryTextListener queryTextListener;
    String url = Config.baseURL + "list_plan.php";
    String userid,menu;
    CircleImageView drawing,paper,painting,thread,bottle,others;
    FloatingActionButton floatingActionButton;

    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {

        View root = inflater.inflate(R.layout.nav_home, container, false);
        imgSaladDiseas = root.findViewById(R.id.imgSaladDiseas);
        recyclerView=root.findViewById(R.id.recycler);
        drawing=root.findViewById(R.id.drawing);
        paper=root.findViewById(R.id.paper);
        painting=root.findViewById(R.id.painting);
        thread=root.findViewById(R.id.thread);
        bottle=root.findViewById(R.id.bottle);
//        others=root.findViewById(R.id.others);

        drawing.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                menu = "Sofa";
                Intent i = new Intent(getActivity(), list_south.class);
                i.putExtra("menu", menu);
                Toast.makeText(getActivity(),menu, Toast.LENGTH_SHORT).show();
                startActivity(i);
            }
        });
        painting.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                menu = "Coat";
                Intent i = new Intent(getActivity(), list_south.class);
                i.putExtra("menu", menu);
                Toast.makeText(getActivity(),menu, Toast.LENGTH_SHORT).show();
                startActivity(i);
            }
        });
        paper.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                menu = "Table";
                Intent i = new Intent(getActivity(), list_south.class);
                i.putExtra("menu", menu);
                Toast.makeText(getActivity(),menu, Toast.LENGTH_SHORT).show();
                startActivity(i);
            }
        });
        thread.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                menu = "Dining Table";
                Intent i = new Intent(getActivity(), list_south.class);
                i.putExtra("menu", menu);
                Toast.makeText(getActivity(),menu, Toast.LENGTH_SHORT).show();
                startActivity(i);
            }
        });
        bottle.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                menu = "Chair";
                Intent i = new Intent(getActivity(), list_south.class);
                i.putExtra("menu", menu);
                Toast.makeText(getActivity(),menu, Toast.LENGTH_SHORT).show();
                startActivity(i);
            }
        });

        AnimationDrawable animationDrawable = (AnimationDrawable) imgSaladDiseas.getDrawable();
        animationDrawable.start();

        setHasOptionsMenu(true);

        fetchingJson();

        return root;
    }

    private void fetchingJson() {
        StringRequest stringRequest = new StringRequest(Request.Method.POST, url,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {

                        try {
//                           / Toast.makeText(getActivity(), response, Toast.LENGTH_SHORT).show();

                            dataModelArrayList = new ArrayList<>();
                            JSONArray array = new JSONArray(response);

                            for (int i = 0; i < array.length(); i++) {

                                JSONObject dataobj = array.getJSONObject(i);


                                dataModelArrayList.add(new PlanModel(
                                        dataobj.getString("id"),
                                        dataobj.getString("cname"),
                                        dataobj.getString("cprice"),
                                        dataobj.getString("cdescription"),
                                        dataobj.getString("clocation"),
                                        dataobj.getString("image"),
                                        dataobj.getString("sellername"),
                                        dataobj.getString("sellerphone"),
                                        dataobj.getString("sellerid"),
                                        dataobj.getString("cquantity"),
                                        null
                                ));
                            }
                            setupRecycler();

                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        // p.setVisibility(View.GONE);
                        // Toast.makeText(getActivity(), error.toString(), Toast.LENGTH_SHORT).show();
                    }
                }) {
            @Override
            protected Map<String, String> getParams() {
                Map<String, String> params = new HashMap<>();

                return params;
            }
        };
        RequestQueue requestQueue = Volley.newRequestQueue(getActivity());
        requestQueue.add(stringRequest);
    }



    private void setupRecycler() {
        rvAdapter = new PlanAdapter(getActivity(), dataModelArrayList);
        recyclerView.setHasFixedSize(true);
        recyclerView.setAdapter(rvAdapter);
        RecyclerView.LayoutManager layoutManager=new GridLayoutManager(getActivity(),2);
        recyclerView.setLayoutManager(layoutManager);
    }

    @Override
    public void onCreateOptionsMenu(Menu menu, MenuInflater inflater) {
        inflater.inflate(R.menu.menu_mains, menu);
        MenuItem searchItem = menu.findItem(R.id.action_search);
        SearchManager searchManager = (SearchManager) getActivity().getSystemService(Context.SEARCH_SERVICE);

        if (searchItem != null) {
            searchView = (SearchView) searchItem.getActionView();
        }
        if (searchView != null) {
            searchView.setSearchableInfo(searchManager.getSearchableInfo(getActivity().getComponentName()));

            queryTextListener = new SearchView.OnQueryTextListener() {
                @Override
                public boolean onQueryTextChange(String newText) {
                    rvAdapter.getFilter().filter(newText);
                    return false;
                }

                @Override
                public boolean onQueryTextSubmit(String query) {
                    rvAdapter.getFilter().filter(query);
                    return false;
                }
            };
            searchView.setOnQueryTextListener(queryTextListener);
        }
        super.onCreateOptionsMenu(menu, inflater);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case R.id.action_search:
                // Not implemented here
                return false;
            default:
                break;
        }
        searchView.setOnQueryTextListener(queryTextListener);
        return super.onOptionsItemSelected(item);

    }
}
